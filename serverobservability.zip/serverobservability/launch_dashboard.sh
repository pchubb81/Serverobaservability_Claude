#!/bin/bash
echo "================================================================"
echo "  Azure Performance Observability - Interactive Dashboard"
echo "================================================================"
echo ""
echo "Starting Streamlit dashboard..."
echo "Dashboard will open in your browser automatically."
echo ""
echo "Press Ctrl+C to stop the dashboard."
echo "================================================================"
echo ""

streamlit run streamlit_app.py
