"""
Correlation Engine for cross-service bottleneck detection
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from datetime import datetime, timedelta
import logging

class CorrelationEngine:
    """Engine for correlating metrics across Azure services to detect bottlenecks"""

    def __init__(self):
        self.logger = logging.getLogger("CorrelationEngine")
        self.correlations = []
        self.bottlenecks = []

    def analyze_correlations(self, agent_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze correlations between different services

        Args:
            agent_results: Dictionary of results from all agents

        Returns:
            Dictionary containing correlation analysis and bottlenecks
        """
        self.logger.info("Starting cross-service correlation analysis...")

        # Extract time series data
        time_series = self._extract_time_series(agent_results)

        # Detect correlations
        self.correlations = self._detect_correlations(time_series)

        # Identify bottlenecks
        self.bottlenecks = self._identify_bottlenecks(agent_results, self.correlations)

        # Identify cascade failures
        cascade_failures = self._detect_cascade_failures(agent_results)

        # Calculate system-wide health
        system_health = self._calculate_system_health(agent_results)

        return {
            'correlations': self.correlations,
            'bottlenecks': self.bottlenecks,
            'cascade_failures': cascade_failures,
            'system_health': system_health
        }

    def _extract_time_series(self, agent_results: Dict[str, Any]) -> Dict[str, pd.DataFrame]:
        """Extract time series data from agent results"""
        time_series = {}

        for service, result in agent_results.items():
            if 'time_series_data' in result and result['time_series_data']:
                df = pd.DataFrame(result['time_series_data'])
                if 'timestamp' in df.columns:
                    df['timestamp'] = pd.to_datetime(df['timestamp'])
                    df = df.sort_values('timestamp')
                    time_series[service] = df

        return time_series

    def _detect_correlations(self, time_series: Dict[str, pd.DataFrame]) -> List[Dict[str, Any]]:
        """Detect correlations between service metrics"""
        correlations = []

        # API -> Redis correlation (cache inefficiency affects API performance)
        if 'API' in time_series and 'RedisCache' in time_series:
            api_df = time_series['API']
            redis_df = time_series['RedisCache']

            # Merge on nearest timestamps
            merged = pd.merge_asof(
                api_df[['timestamp', 'response_time_ms']].sort_values('timestamp'),
                redis_df[['timestamp', 'cache_hit_rate']].sort_values('timestamp'),
                on='timestamp',
                direction='nearest',
                tolerance=pd.Timedelta('5min')
            )

            if len(merged) > 10:
                corr = merged['response_time_ms'].corr(1 - merged['cache_hit_rate'])
                if abs(corr) > 0.5:
                    correlations.append({
                        'services': ['API', 'RedisCache'],
                        'type': 'Cache Efficiency Impact',
                        'correlation': float(corr),
                        'description': f"Low Redis cache hit rate correlates with higher API response times (r={corr:.2f})",
                        'severity': 'high' if abs(corr) > 0.7 else 'medium'
                    })

        # API -> SQL correlation (database performance affects API)
        if 'API' in time_series and 'SQLServer' in time_series:
            api_df = time_series['API']
            sql_df = time_series['SQLServer']

            merged = pd.merge_asof(
                api_df[['timestamp', 'response_time_ms']].sort_values('timestamp'),
                sql_df[['timestamp', 'avg_query_time_ms']].sort_values('timestamp'),
                on='timestamp',
                direction='nearest',
                tolerance=pd.Timedelta('5min')
            )

            if len(merged) > 10:
                corr = merged['response_time_ms'].corr(merged['avg_query_time_ms'])
                if abs(corr) > 0.5:
                    correlations.append({
                        'services': ['API', 'SQLServer'],
                        'type': 'Database Performance Impact',
                        'correlation': float(corr),
                        'description': f"SQL query times correlate with API response times (r={corr:.2f})",
                        'severity': 'high' if abs(corr) > 0.7 else 'medium'
                    })

        # AKS -> All services (infrastructure affects everything)
        if 'AKS' in time_series:
            aks_df = time_series['AKS']
            avg_cpu = aks_df.groupby('timestamp')['cpu_usage_percent'].mean().reset_index()

            for service in ['API', 'SQLServer', 'RedisCache']:
                if service in time_series:
                    service_df = time_series[service]

                    # Find a metric to correlate (response time, latency, etc.)
                    metric_col = None
                    if service == 'API' and 'response_time_ms' in service_df.columns:
                        metric_col = 'response_time_ms'
                    elif service == 'SQLServer' and 'avg_query_time_ms' in service_df.columns:
                        metric_col = 'avg_query_time_ms'
                    elif service == 'RedisCache' and 'server_load_percent' in service_df.columns:
                        metric_col = 'server_load_percent'

                    if metric_col:
                        merged = pd.merge_asof(
                            service_df[['timestamp', metric_col]].sort_values('timestamp'),
                            avg_cpu.sort_values('timestamp'),
                            on='timestamp',
                            direction='nearest',
                            tolerance=pd.Timedelta('5min')
                        )

                        if len(merged) > 10:
                            corr = merged[metric_col].corr(merged['cpu_usage_percent'])
                            if abs(corr) > 0.5:
                                correlations.append({
                                    'services': ['AKS', service],
                                    'type': 'Infrastructure Resource Contention',
                                    'correlation': float(corr),
                                    'description': f"AKS CPU usage correlates with {service} {metric_col} (r={corr:.2f})",
                                    'severity': 'high' if abs(corr) > 0.7 else 'medium'
                                })

        return correlations

    def _identify_bottlenecks(self, agent_results: Dict[str, Any], correlations: List[Dict]) -> List[Dict[str, Any]]:
        """Identify system bottlenecks based on metrics and correlations"""
        bottlenecks = []

        # Check each service's health and anomalies
        for service, result in agent_results.items():
            if not result:
                continue

            health_score = result.get('health_score', 100)
            anomalies = result.get('anomalies', [])
            metrics = result.get('metrics', {})

            # Critical health score indicates bottleneck
            if health_score < 50:
                severity_count = len([a for a in anomalies if a.get('severity') in ['critical', 'high']])
                bottlenecks.append({
                    'service': service,
                    'type': 'Performance Degradation',
                    'severity': 'critical' if health_score < 30 else 'high',
                    'health_score': health_score,
                    'description': f"{service} health score is {health_score:.1f} with {severity_count} critical issues",
                    'impact': self._assess_impact(service, correlations),
                    'recommendations': self._get_recommendations(service, result)
                })

        # Identify cascade bottlenecks (one service affecting others)
        for corr in correlations:
            if corr['correlation'] > 0.7 and corr['severity'] == 'high':
                # Determine which service is the root cause
                services = corr['services']
                root_cause = self._determine_root_cause(services, agent_results)

                if root_cause:
                    bottlenecks.append({
                        'service': root_cause,
                        'type': 'Cascade Bottleneck',
                        'severity': 'critical',
                        'description': f"{root_cause} performance issues are cascading to {', '.join([s for s in services if s != root_cause])}",
                        'impact': f"Affects {len(services)} services",
                        'correlation': corr['correlation'],
                        'affected_services': services,
                        'recommendations': self._get_cascade_recommendations(root_cause, services)
                    })

        # Resource contention bottlenecks
        aks_result = agent_results.get('AKS', {})
        if aks_result:
            aks_metrics = aks_result.get('metrics', {})
            if aks_metrics.get('p95_cpu_usage', 0) > 80 or aks_metrics.get('p95_memory_usage', 0) > 85:
                affected_services = [s for s in agent_results.keys() if s != 'AKS']
                bottlenecks.append({
                    'service': 'AKS',
                    'type': 'Resource Contention',
                    'severity': 'critical',
                    'description': 'AKS resource constraints are limiting overall system performance',
                    'impact': f"Affects all services running on AKS: {', '.join(affected_services)}",
                    'recommendations': [
                        'Scale AKS cluster horizontally (add more nodes)',
                        'Increase node resource limits (CPU/memory)',
                        'Optimize pod resource requests and limits',
                        'Consider vertical pod autoscaling'
                    ]
                })

        return bottlenecks

    def _determine_root_cause(self, services: List[str], agent_results: Dict[str, Any]) -> str:
        """Determine root cause service in a correlation"""
        # Priority order: Infrastructure -> Database -> Cache -> API/Blob
        priority = {'AKS': 0, 'SQLServer': 1, 'RedisCache': 2, 'BlobStorage': 3, 'API': 4}

        services_with_issues = []
        for service in services:
            if service in agent_results:
                health = agent_results[service].get('health_score', 100)
                if health < 70:
                    services_with_issues.append((service, priority.get(service, 999), health))

        if services_with_issues:
            # Sort by priority (lower is higher priority) and health (lower is worse)
            services_with_issues.sort(key=lambda x: (x[1], x[2]))
            return services_with_issues[0][0]

        return None

    def _assess_impact(self, service: str, correlations: List[Dict]) -> str:
        """Assess the impact of a service's issues"""
        affected = set()
        for corr in correlations:
            if service in corr['services']:
                affected.update([s for s in corr['services'] if s != service])

        if len(affected) > 0:
            return f"Impacts {len(affected)} other service(s): {', '.join(affected)}"
        return "Isolated to this service"

    def _get_recommendations(self, service: str, result: Dict[str, Any]) -> List[str]:
        """Get recommendations based on service issues"""
        recommendations = []
        insights = result.get('insights', [])

        # Extract actionable recommendations from insights
        for insight in insights:
            if '⚠️' in insight or '🔴' in insight:
                recommendations.append(insight.replace('⚠️', '').replace('🔴', '').strip())

        if not recommendations:
            recommendations.append(f"Review {service} metrics and optimize resource allocation")

        return recommendations[:3]  # Top 3 recommendations

    def _get_cascade_recommendations(self, root_cause: str, affected_services: List[str]) -> List[str]:
        """Get recommendations for cascade failures"""
        recommendations = [
            f"Prioritize fixing {root_cause} as it's the root cause",
            f"Monitor {', '.join([s for s in affected_services if s != root_cause])} for cascading effects",
            "Implement circuit breakers to prevent cascade failures",
            "Add timeout and retry logic with exponential backoff"
        ]
        return recommendations

    def _detect_cascade_failures(self, agent_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect cascade failure patterns"""
        cascade_failures = []

        # Check for time-correlated failures across services
        services_with_issues = {}
        for service, result in agent_results.items():
            if result and result.get('anomalies'):
                critical_anomalies = [a for a in result['anomalies'] if a.get('severity') in ['critical', 'high']]
                if critical_anomalies:
                    services_with_issues[service] = critical_anomalies

        # If multiple services have issues, it may be a cascade
        if len(services_with_issues) >= 2:
            cascade_failures.append({
                'type': 'Multi-Service Degradation',
                'severity': 'critical',
                'affected_services': list(services_with_issues.keys()),
                'description': f"{len(services_with_issues)} services experiencing simultaneous issues",
                'pattern': 'Potential cascade failure or shared infrastructure issue'
            })

        return cascade_failures

    def _calculate_system_health(self, agent_results: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall system health"""
        health_scores = []
        service_statuses = {}

        for service, result in agent_results.items():
            if result and 'health_score' in result:
                score = result['health_score']
                health_scores.append(score)

                # Categorize status
                if score >= 80:
                    status = 'healthy'
                elif score >= 60:
                    status = 'warning'
                elif score >= 40:
                    status = 'degraded'
                else:
                    status = 'critical'

                service_statuses[service] = {
                    'score': score,
                    'status': status,
                    'anomaly_count': len(result.get('anomalies', []))
                }

        # Calculate weighted average (infrastructure services weighted higher)
        weights = {
            'AKS': 1.5,
            'SQLServer': 1.3,
            'RedisCache': 1.2,
            'API': 1.0,
            'BlobStorage': 1.0
        }

        weighted_sum = 0
        weight_total = 0

        for service, status_info in service_statuses.items():
            weight = weights.get(service, 1.0)
            weighted_sum += status_info['score'] * weight
            weight_total += weight

        overall_score = weighted_sum / weight_total if weight_total > 0 else 100

        # Overall status
        if overall_score >= 80:
            overall_status = 'healthy'
        elif overall_score >= 60:
            overall_status = 'warning'
        elif overall_score >= 40:
            overall_status = 'degraded'
        else:
            overall_status = 'critical'

        return {
            'overall_score': round(overall_score, 1),
            'overall_status': overall_status,
            'service_statuses': service_statuses,
            'services_healthy': len([s for s, info in service_statuses.items() if info['status'] == 'healthy']),
            'services_warning': len([s for s, info in service_statuses.items() if info['status'] == 'warning']),
            'services_degraded': len([s for s, info in service_statuses.items() if info['status'] == 'degraded']),
            'services_critical': len([s for s, info in service_statuses.items() if info['status'] == 'critical'])
        }
