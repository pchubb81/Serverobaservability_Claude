"""
Technical Report Generator
"""

from pathlib import Path
from typing import Dict, Any
from datetime import datetime
import plotly.io as pio
import json

from ..visualizers.chart_generator import ChartGenerator

class TechnicalReportGenerator:
    """Generate detailed technical reports for engineering teams"""

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.chart_gen = ChartGenerator()

    def generate(self, results: Dict[str, Any], output_format: str = 'html') -> str:
        """Generate technical report

        Args:
            results: Analysis results
            output_format: Output format ('html' or 'pdf')

        Returns:
            Path to generated report
        """
        # Build HTML report
        html_content = self._build_html(results)

        # Save report
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_path = self.output_dir / f'technical_report_{timestamp}.html'
        report_path.write_text(html_content, encoding='utf-8')

        return str(report_path)

    def _build_html(self, results: Dict[str, Any]) -> str:
        """Build technical HTML report"""
        summary = results.get('summary', {})
        correlation_analysis = results.get('correlation_analysis', {})

        # Generate service sections
        service_sections = []
        for service in ['AKS', 'SQLServer', 'BlobStorage', 'API', 'RedisCache']:
            if service in results and results[service]:
                section = self._build_service_section(service, results[service])
                service_sections.append(section)

        # Correlation section
        correlation_section = self._build_correlation_section(correlation_analysis)

        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Report - Azure Performance Analysis</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 20px;
            line-height: 1.6;
        }}

        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: #2d2d2d;
            box-shadow: 0 0 30px rgba(0,0,0,0.5);
        }}

        header {{
            background: #0e639c;
            color: white;
            padding: 40px;
        }}

        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}

        header .subtitle {{
            font-size: 1.2em;
            opacity: 0.9;
        }}

        header .metadata {{
            margin-top: 20px;
            font-size: 0.9em;
            opacity: 0.8;
            font-family: monospace;
        }}

        .toc {{
            background: #252526;
            padding: 30px;
            border-bottom: 3px solid #0e639c;
        }}

        .toc h2 {{
            color: #4ec9b0;
            margin-bottom: 15px;
        }}

        .toc ul {{
            list-style: none;
        }}

        .toc ul li {{
            padding: 8px 0;
        }}

        .toc ul li a {{
            color: #9cdcfe;
            text-decoration: none;
        }}

        .toc ul li a:hover {{
            color: #4ec9b0;
            text-decoration: underline;
        }}

        .content {{
            padding: 40px;
        }}

        .section {{
            margin-bottom: 50px;
            padding: 30px;
            background: #252526;
            border-left: 5px solid #0e639c;
            border-radius: 5px;
        }}

        h2 {{
            color: #4ec9b0;
            margin-bottom: 20px;
            font-size: 2em;
            padding-bottom: 10px;
            border-bottom: 2px solid #3e3e42;
        }}

        h3 {{
            color: #9cdcfe;
            margin: 20px 0 15px 0;
            font-size: 1.5em;
        }}

        h4 {{
            color: #dcdcaa;
            margin: 15px 0 10px 0;
        }}

        .metric-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}

        .metric-item {{
            background: #1e1e1e;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #3e3e42;
        }}

        .metric-item .label {{
            color: #858585;
            font-size: 0.85em;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }}

        .metric-item .value {{
            color: #ce9178;
            font-size: 1.5em;
            font-weight: bold;
        }}

        .anomaly-list {{
            list-style: none;
        }}

        .anomaly-list li {{
            background: #1e1e1e;
            margin: 15px 0;
            padding: 20px;
            border-left: 5px solid #d16969;
            border-radius: 5px;
        }}

        .anomaly-list li.severity-critical {{
            border-left-color: #f44336;
        }}

        .anomaly-list li.severity-high {{
            border-left-color: #ff9800;
        }}

        .anomaly-list li.severity-medium {{
            border-left-color: #ffc107;
        }}

        .anomaly-title {{
            color: #d16969;
            font-size: 1.2em;
            margin-bottom: 10px;
        }}

        .anomaly-description {{
            color: #d4d4d4;
            margin: 10px 0;
        }}

        .severity-badge {{
            display: inline-block;
            padding: 5px 15px;
            border-radius: 3px;
            font-size: 0.85em;
            font-weight: bold;
            margin-top: 10px;
        }}

        .severity-badge.critical {{
            background: #f44336;
            color: white;
        }}

        .severity-badge.high {{
            background: #ff9800;
            color: white;
        }}

        .severity-badge.medium {{
            background: #ffc107;
            color: #333;
        }}

        .insights-list {{
            list-style: none;
        }}

        .insights-list li {{
            background: #1e1e1e;
            padding: 15px;
            margin: 10px 0;
            border-left: 3px solid #4ec9b0;
            border-radius: 5px;
        }}

        .code-block {{
            background: #1e1e1e;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #3e3e42;
            overflow-x: auto;
            margin: 15px 0;
        }}

        .code-block pre {{
            color: #d4d4d4;
            font-family: 'Consolas', 'Monaco', monospace;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: #1e1e1e;
        }}

        table th {{
            background: #0e639c;
            color: white;
            padding: 12px;
            text-align: left;
        }}

        table td {{
            padding: 12px;
            border-bottom: 1px solid #3e3e42;
        }}

        table tr:hover {{
            background: #252526;
        }}

        footer {{
            background: #252526;
            padding: 30px;
            text-align: center;
            color: #858585;
            border-top: 1px solid #3e3e42;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>⚙️ Technical Performance Report</h1>
            <p class="subtitle">Detailed Azure Multi-Service Analysis</p>
            <p class="metadata">
                Generated: {summary.get('analysis_timestamp', 'N/A')}<br>
                Services: {summary.get('services_analyzed', 0)} |
                Anomalies: {summary.get('total_anomalies', 0)} |
                Bottlenecks: {summary.get('bottlenecks_count', 0)}
            </p>
        </header>

        <div class="toc">
            <h2>📋 Table of Contents</h2>
            <ul>
                <li><a href="#correlation">Cross-Service Analysis</a></li>
                {''.join([f'<li><a href="#{service.lower()}">{service} Analysis</a></li>' for service in ['AKS', 'SQLServer', 'BlobStorage', 'API', 'RedisCache'] if service in results and results[service]])}
            </ul>
        </div>

        <div class="content">
            {correlation_section}
            {''.join(service_sections)}
        </div>

        <footer>
            <p><strong>Azure Server Performance Observability System</strong></p>
            <p>Detailed Technical Analysis for Engineering Teams</p>
        </footer>
    </div>
</body>
</html>
"""
        return html

    def _build_service_section(self, service: str, service_data: Dict[str, Any]) -> str:
        """Build HTML section for a service"""
        metrics = service_data.get('metrics', {})
        anomalies = service_data.get('anomalies', [])
        insights = service_data.get('insights', [])
        health_score = service_data.get('health_score', 'N/A')

        # Build metrics grid
        metrics_html = '<div class="metric-grid">'
        for key, value in metrics.items():
            display_key = key.replace('_', ' ').title()
            if isinstance(value, float):
                display_value = f"{value:.2f}"
            else:
                display_value = str(value)

            metrics_html += f'''
            <div class="metric-item">
                <div class="label">{display_key}</div>
                <div class="value">{display_value}</div>
            </div>
            '''
        metrics_html += '</div>'

        # Build anomalies list
        anomalies_html = ''
        if anomalies:
            anomalies_html = '<h3>🚨 Anomalies Detected</h3><ul class="anomaly-list">'
            for anomaly in anomalies:
                severity = anomaly.get('severity', 'medium')
                anomalies_html += f'''
                <li class="severity-{severity}">
                    <div class="anomaly-title">{anomaly.get('type', 'Unknown')}</div>
                    <div class="anomaly-description">{anomaly.get('description', '')}</div>
                    <span class="severity-badge {severity}">{severity.upper()}</span>
                </li>
                '''
            anomalies_html += '</ul>'

        # Build insights list
        insights_html = ''
        if insights:
            insights_html = '<h3>💡 Key Insights</h3><ul class="insights-list">'
            for insight in insights:
                insights_html += f'<li>{insight}</li>'
            insights_html += '</ul>'

        section = f'''
        <div class="section" id="{service.lower()}">
            <h2>{service} Analysis</h2>
            <div class="metric-item" style="max-width: 300px; margin-bottom: 20px;">
                <div class="label">Health Score</div>
                <div class="value" style="color: {self._get_health_color(health_score)};">{health_score}</div>
            </div>

            <h3>📊 Key Metrics</h3>
            {metrics_html}

            {anomalies_html}

            {insights_html}
        </div>
        '''

        return section

    def _build_correlation_section(self, correlation_analysis: Dict[str, Any]) -> str:
        """Build correlation analysis section"""
        system_health = correlation_analysis.get('system_health', {})
        correlations = correlation_analysis.get('correlations', [])
        bottlenecks = correlation_analysis.get('bottlenecks', [])

        # System health overview
        health_html = f'''
        <h3>System Health Overview</h3>
        <div class="metric-grid">
            <div class="metric-item">
                <div class="label">Overall Score</div>
                <div class="value" style="color: {self._get_health_color(system_health.get('overall_score', 0))};">
                    {system_health.get('overall_score', 'N/A')}
                </div>
            </div>
            <div class="metric-item">
                <div class="label">Status</div>
                <div class="value">{system_health.get('overall_status', 'Unknown').upper()}</div>
            </div>
            <div class="metric-item">
                <div class="label">Healthy Services</div>
                <div class="value" style="color: #4CAF50;">{system_health.get('services_healthy', 0)}</div>
            </div>
            <div class="metric-item">
                <div class="label">Critical Services</div>
                <div class="value" style="color: #F44336;">{system_health.get('services_critical', 0)}</div>
            </div>
        </div>
        '''

        # Correlations
        correlations_html = ''
        if correlations:
            correlations_html = '<h3>🔗 Service Correlations</h3><ul class="anomaly-list">'
            for corr in correlations:
                correlations_html += f'''
                <li class="severity-{corr.get('severity', 'medium')}">
                    <div class="anomaly-title">{' ↔️ '.join(corr.get('services', []))}</div>
                    <div class="anomaly-description">
                        {corr.get('description', '')}<br>
                        <strong>Correlation coefficient:</strong> {corr.get('correlation', 0):.3f}
                    </div>
                    <span class="severity-badge {corr.get('severity', 'medium')}">{corr.get('type', 'Correlation')}</span>
                </li>
                '''
            correlations_html += '</ul>'

        # Bottlenecks
        bottlenecks_html = ''
        if bottlenecks:
            bottlenecks_html = '<h3>⚠️ Performance Bottlenecks</h3><ul class="anomaly-list">'
            for bn in bottlenecks:
                recommendations = bn.get('recommendations', [])
                recs_html = '<ul>' + ''.join([f'<li>{rec}</li>' for rec in recommendations]) + '</ul>'

                bottlenecks_html += f'''
                <li class="severity-{bn.get('severity', 'high')}">
                    <div class="anomaly-title">{bn.get('service')} - {bn.get('type')}</div>
                    <div class="anomaly-description">
                        {bn.get('description', '')}<br>
                        <strong>Impact:</strong> {bn.get('impact', 'N/A')}<br>
                        <strong>Recommendations:</strong>
                        {recs_html}
                    </div>
                    <span class="severity-badge {bn.get('severity', 'high')}">{bn.get('severity', 'HIGH').upper()}</span>
                </li>
                '''
            bottlenecks_html += '</ul>'

        section = f'''
        <div class="section" id="correlation">
            <h2>🔍 Cross-Service Correlation Analysis</h2>

            {health_html}

            {correlations_html}

            {bottlenecks_html}
        </div>
        '''

        return section

    def _get_health_color(self, score: Any) -> str:
        """Get color for health score"""
        if score == 'N/A' or not isinstance(score, (int, float)):
            return '#858585'

        if score >= 80:
            return '#4CAF50'
        elif score >= 60:
            return '#8BC34A'
        elif score >= 40:
            return '#FF9800'
        else:
            return '#F44336'
