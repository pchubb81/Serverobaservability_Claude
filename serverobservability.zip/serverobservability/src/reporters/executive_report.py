"""
Executive Summary Report Generator
"""

from pathlib import Path
from typing import Dict, Any
from datetime import datetime
import plotly.io as pio

from ..visualizers.chart_generator import ChartGenerator

class ExecutiveReportGenerator:
    """Generate executive summary reports for leadership"""

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.chart_gen = ChartGenerator()

    def generate(self, results: Dict[str, Any], output_format: str = 'html') -> str:
        """Generate executive summary report

        Args:
            results: Analysis results
            output_format: Output format ('html' or 'pdf')

        Returns:
            Path to generated report
        """
        summary = results.get('summary', {})
        correlation_analysis = results.get('correlation_analysis', {})
        system_health = correlation_analysis.get('system_health', {})
        bottlenecks = correlation_analysis.get('bottlenecks', [])

        # Generate key visualizations
        charts_html = []

        if system_health.get('overall_score'):
            health_gauge = self.chart_gen.create_health_score_gauge(
                system_health['overall_score'],
                "Overall System Health"
            )
            charts_html.append(pio.to_html(health_gauge, include_plotlyjs='cdn', full_html=False))

        if system_health:
            status_pie = self.chart_gen.create_service_status_pie(system_health)
            charts_html.append(pio.to_html(status_pie, include_plotlyjs=False, full_html=False))

        # Build HTML report
        html_content = self._build_html(summary, system_health, bottlenecks, charts_html)

        # Save report
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_path = self.output_dir / f'executive_summary_{timestamp}.html'
        report_path.write_text(html_content, encoding='utf-8')

        return str(report_path)

    def _build_html(self, summary: Dict, system_health: Dict,
                   bottlenecks: list, charts_html: list) -> str:
        """Build executive HTML report"""

        # Extract key insights
        critical_issues = summary.get('critical_issues', [])[:5]

        critical_section = ""
        if critical_issues:
            critical_section = "<h2>🔴 Critical Issues Requiring Attention</h2><ol>"
            for issue in critical_issues:
                critical_section += f"""
                <li class="critical-item">
                    <strong>{issue.get('service')}</strong>: {issue.get('type')}
                    <p>{issue.get('description')}</p>
                    <span class="severity severity-{issue.get('severity', 'medium')}">{issue.get('severity', 'medium').upper()}</span>
                </li>
                """
            critical_section += "</ol>"

        bottleneck_section = ""
        if bottlenecks:
            bottleneck_section = "<h2>⚠️ Performance Bottlenecks</h2><div class='bottlenecks'>"
            for bn in bottlenecks[:3]:
                recommendations = bn.get('recommendations', [])
                recs_html = "<ul>" + "".join([f"<li>{rec}</li>" for rec in recommendations[:3]]) + "</ul>"

                bottleneck_section += f"""
                <div class="bottleneck-card">
                    <h3>{bn.get('service')} - {bn.get('type')}</h3>
                    <p class="description">{bn.get('description')}</p>
                    <p class="impact"><strong>Impact:</strong> {bn.get('impact', 'N/A')}</p>
                    <div class="recommendations">
                        <strong>Recommended Actions:</strong>
                        {recs_html}
                    </div>
                </div>
                """
            bottleneck_section += "</div>"

        charts_section = "\n".join([f'<div class="chart">{chart}</div>' for chart in charts_html])

        # Service status breakdown
        service_status_html = ""
        if system_health.get('service_statuses'):
            service_status_html = "<h2>📊 Service Health Overview</h2><div class='service-grid'>"
            for service, status_info in system_health['service_statuses'].items():
                score = status_info['score']
                status = status_info['status']
                anomalies = status_info['anomaly_count']

                service_status_html += f"""
                <div class="service-card status-{status}">
                    <h3>{service}</h3>
                    <div class="score">{score:.1f}</div>
                    <div class="status-label">{status.upper()}</div>
                    <div class="anomalies">{anomalies} anomalies</div>
                </div>
                """
            service_status_html += "</div>"

        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Summary - Azure Performance Analysis</title>
    <style>
        @media print {{
            body {{ background: white; }}
            .container {{ box-shadow: none; }}
        }}

        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: Georgia, 'Times New Roman', serif;
            background: #f5f5f5;
            padding: 20px;
            color: #333;
            line-height: 1.6;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }}

        header {{
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}

        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: normal;
        }}

        header .subtitle {{
            font-size: 1.2em;
            opacity: 0.9;
            font-style: italic;
        }}

        header .metadata {{
            margin-top: 20px;
            font-size: 0.9em;
            opacity: 0.8;
        }}

        .executive-summary {{
            background: #f8f9fa;
            padding: 40px;
            border-left: 5px solid #2a5298;
        }}

        .executive-summary h2 {{
            color: #1e3c72;
            margin-bottom: 20px;
            font-size: 1.8em;
        }}

        .executive-summary p {{
            font-size: 1.1em;
            margin-bottom: 15px;
        }}

        .key-metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 40px;
        }}

        .metric-box {{
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            border-top: 4px solid #2a5298;
        }}

        .metric-box .value {{
            font-size: 3em;
            font-weight: bold;
            margin: 15px 0;
        }}

        .metric-box .label {{
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.85em;
        }}

        .metric-box.healthy .value {{ color: #4CAF50; }}
        .metric-box.warning .value {{ color: #FFC107; }}
        .metric-box.critical .value {{ color: #F44336; }}

        .content {{
            padding: 40px;
        }}

        h2 {{
            color: #1e3c72;
            margin: 30px 0 20px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #e0e0e0;
            font-size: 1.8em;
        }}

        h3 {{
            color: #2a5298;
            margin: 20px 0 10px 0;
        }}

        .critical-item {{
            background: #fff5f5;
            padding: 20px;
            margin: 15px 0;
            border-left: 5px solid #F44336;
            border-radius: 5px;
        }}

        .critical-item p {{
            margin: 10px 0;
            color: #666;
        }}

        .severity {{
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8em;
            font-weight: bold;
            margin-top: 10px;
        }}

        .severity-critical {{ background: #F44336; color: white; }}
        .severity-high {{ background: #FF9800; color: white; }}
        .severity-medium {{ background: #FFC107; color: #333; }}

        .bottleneck-card {{
            background: white;
            border: 1px solid #e0e0e0;
            border-left: 5px solid #FF9800;
            padding: 25px;
            margin: 20px 0;
            border-radius: 5px;
        }}

        .bottleneck-card h3 {{
            color: #FF9800;
            margin-bottom: 15px;
        }}

        .bottleneck-card .description {{
            font-size: 1.05em;
            margin: 15px 0;
        }}

        .bottleneck-card .impact {{
            color: #666;
            margin: 10px 0;
            font-style: italic;
        }}

        .recommendations {{
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }}

        .recommendations ul {{
            margin-left: 20px;
        }}

        .recommendations li {{
            margin: 8px 0;
        }}

        .service-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}

        .service-card {{
            background: white;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}

        .service-card h3 {{
            color: #333;
            margin-bottom: 15px;
            font-size: 1.1em;
        }}

        .service-card .score {{
            font-size: 2.5em;
            font-weight: bold;
            margin: 10px 0;
        }}

        .service-card.status-healthy {{
            border-top: 5px solid #4CAF50;
        }}

        .service-card.status-healthy .score {{
            color: #4CAF50;
        }}

        .service-card.status-warning {{
            border-top: 5px solid #FFC107;
        }}

        .service-card.status-warning .score {{
            color: #FFC107;
        }}

        .service-card.status-degraded {{
            border-top: 5px solid #FF9800;
        }}

        .service-card.status-degraded .score {{
            color: #FF9800;
        }}

        .service-card.status-critical {{
            border-top: 5px solid #F44336;
        }}

        .service-card.status-critical .score {{
            color: #F44336;
        }}

        .status-label {{
            font-size: 0.85em;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 10px 0;
        }}

        .anomalies {{
            color: #666;
            font-size: 0.9em;
        }}

        .chart {{
            margin: 30px 0;
        }}

        footer {{
            background: #f8f9fa;
            padding: 30px;
            text-align: center;
            color: #666;
            border-top: 1px solid #e0e0e0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Executive Summary</h1>
            <p class="subtitle">Azure Server Performance Analysis</p>
            <p class="metadata">
                Analysis Date: {summary.get('analysis_timestamp', 'N/A')}<br>
                Services Analyzed: {summary.get('services_analyzed', 0)}
            </p>
        </header>

        <div class="executive-summary">
            <h2>Key Findings</h2>
            <p>
                System health score is <strong>{system_health.get('overall_score', 'N/A')}</strong> with
                overall status: <strong>{system_health.get('overall_status', 'Unknown').upper()}</strong>.
            </p>
            <p>
                Analysis identified <strong>{summary.get('total_anomalies', 0)}</strong> anomalies across
                all services, with <strong>{summary.get('critical_issues_count', 0)}</strong> requiring
                immediate attention.
            </p>
            <p>
                <strong>{summary.get('bottlenecks_count', 0)}</strong> performance bottlenecks were detected
                that may impact overall system performance and user experience.
            </p>
        </div>

        <div class="key-metrics">
            <div class="metric-box {self._get_status_class(system_health.get('overall_status', 'unknown'))}">
                <div class="label">Health Score</div>
                <div class="value">{system_health.get('overall_score', 'N/A')}</div>
            </div>

            <div class="metric-box {self._get_anomaly_class(summary.get('total_anomalies', 0))}">
                <div class="label">Total Anomalies</div>
                <div class="value">{summary.get('total_anomalies', 0)}</div>
            </div>

            <div class="metric-box critical">
                <div class="label">Bottlenecks</div>
                <div class="value">{summary.get('bottlenecks_count', 0)}</div>
            </div>

            <div class="metric-box">
                <div class="label">Services Analyzed</div>
                <div class="value">{summary.get('services_analyzed', 0)}</div>
            </div>
        </div>

        <div class="content">
            {critical_section}

            {bottleneck_section}

            {service_status_html}

            <h2>📈 Performance Visualizations</h2>
            {charts_section}
        </div>

        <footer>
            <p><strong>Azure Server Performance Observability System</strong></p>
            <p>AI-Powered Multi-Service Analysis & Bottleneck Detection</p>
            <p style="margin-top: 10px; font-size: 0.9em;">
                This executive summary provides a high-level overview of system performance.<br>
                For detailed technical analysis, please refer to the Technical Report.
            </p>
        </footer>
    </div>
</body>
</html>
"""
        return html

    def _get_status_class(self, status: str) -> str:
        """Get CSS class for status"""
        status_map = {
            'healthy': 'healthy',
            'warning': 'warning',
            'degraded': 'warning',
            'critical': 'critical'
        }
        return status_map.get(status.lower(), '')

    def _get_anomaly_class(self, count: int) -> str:
        """Get CSS class for anomaly count"""
        if count == 0:
            return 'healthy'
        elif count < 10:
            return 'warning'
        else:
            return 'critical'
