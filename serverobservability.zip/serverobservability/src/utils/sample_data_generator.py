"""
Sample Azure metrics data generator for testing
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from pathlib import Path

def generate_timestamps(start_time, duration_hours, interval_seconds):
    """Generate timestamp array"""
    start = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
    timestamps = []
    current = start
    end = start + timedelta(hours=duration_hours)

    while current <= end:
        timestamps.append(current)
        current += timedelta(seconds=interval_seconds)

    return timestamps

def generate_aks_metrics(output_dir: Path):
    """Generate AKS (Kubernetes) metrics"""
    timestamps = generate_timestamps('2026-01-14 00:00:00', duration_hours=24, interval_seconds=60)

    data = {
        'timestamp': timestamps,
        'pod_name': [f'api-pod-{i % 5}' for i in range(len(timestamps))],
        'node_name': [f'aks-node-{i % 3}' for i in range(len(timestamps))],
        'cpu_usage_percent': np.random.normal(45, 15, len(timestamps)).clip(5, 100),
        'memory_usage_mb': np.random.normal(1024, 256, len(timestamps)).clip(100, 4096),
        'memory_limit_mb': 2048,
        'network_rx_bytes': np.random.exponential(1000000, len(timestamps)),
        'network_tx_bytes': np.random.exponential(800000, len(timestamps)),
        'disk_read_ops': np.random.poisson(50, len(timestamps)),
        'disk_write_ops': np.random.poisson(30, len(timestamps)),
        'restart_count': np.random.poisson(0.1, len(timestamps)).astype(int),
        'pod_status': np.random.choice(['Running', 'Running', 'Running', 'Pending'], len(timestamps))
    }

    # Add some anomalies
    anomaly_indices = np.random.choice(len(timestamps), size=10, replace=False)
    data['cpu_usage_percent'][anomaly_indices] = np.random.uniform(85, 98, 10)
    data['memory_usage_mb'][anomaly_indices] = np.random.uniform(1800, 2000, 10)

    df = pd.DataFrame(data)
    df.to_csv(output_dir / 'aks_metrics.csv', index=False)
    print(f"  + Generated AKS metrics: {len(df)} records")

def generate_sql_metrics(output_dir: Path):
    """Generate Azure SQL Server metrics"""
    timestamps = generate_timestamps('2026-01-14 00:00:00', duration_hours=24, interval_seconds=300)

    data = {
        'timestamp': timestamps,
        'server_name': 'azure-sql-prod-01',
        'database_name': np.random.choice(['UserDB', 'OrderDB', 'AnalyticsDB'], len(timestamps)),
        'dtu_percent': np.random.normal(35, 12, len(timestamps)).clip(0, 100),
        'cpu_percent': np.random.normal(40, 15, len(timestamps)).clip(0, 100),
        'data_io_percent': np.random.normal(30, 10, len(timestamps)).clip(0, 100),
        'log_io_percent': np.random.normal(25, 8, len(timestamps)).clip(0, 100),
        'memory_percent': np.random.normal(55, 10, len(timestamps)).clip(0, 100),
        'active_connections': np.random.poisson(45, len(timestamps)),
        'blocked_connections': np.random.poisson(2, len(timestamps)),
        'deadlocks': np.random.poisson(0.5, len(timestamps)),
        'avg_query_time_ms': np.random.exponential(150, len(timestamps)),
        'slow_queries': np.random.poisson(5, len(timestamps)),
        'failed_connections': np.random.poisson(1, len(timestamps))
    }

    # Add performance degradation period
    degradation_start = len(timestamps) // 2
    degradation_end = degradation_start + 20
    data['avg_query_time_ms'][degradation_start:degradation_end] = np.random.exponential(800, degradation_end - degradation_start)
    data['blocked_connections'][degradation_start:degradation_end] = np.random.poisson(15, degradation_end - degradation_start)

    df = pd.DataFrame(data)
    df.to_excel(output_dir / 'sql_server_metrics.xlsx', index=False)
    print(f"  + Generated SQL Server metrics: {len(df)} records")

def generate_blob_metrics(output_dir: Path):
    """Generate Azure Blob Storage metrics"""
    timestamps = generate_timestamps('2026-01-14 00:00:00', duration_hours=24, interval_seconds=180)

    data = {
        'timestamp': timestamps,
        'storage_account': 'azureblobprod',
        'container_name': np.random.choice(['images', 'documents', 'backups', 'logs'], len(timestamps)),
        'total_requests': np.random.poisson(500, len(timestamps)),
        'successful_requests': np.random.poisson(485, len(timestamps)),
        'throttled_requests': np.random.poisson(2, len(timestamps)),
        'avg_e2e_latency_ms': np.random.exponential(50, len(timestamps)),
        'avg_server_latency_ms': np.random.exponential(30, len(timestamps)),
        'ingress_bytes': np.random.exponential(5000000, len(timestamps)),
        'egress_bytes': np.random.exponential(8000000, len(timestamps)),
        'capacity_bytes': np.random.normal(5e11, 1e10, len(timestamps)),
        'blob_count': np.random.normal(50000, 5000, len(timestamps)).astype(int),
        'transactions_per_sec': np.random.normal(100, 20, len(timestamps))
    }

    # Add latency spikes
    spike_indices = np.random.choice(len(timestamps), size=5, replace=False)
    data['avg_e2e_latency_ms'][spike_indices] = np.random.uniform(500, 1000, 5)
    data['throttled_requests'][spike_indices] = np.random.poisson(50, 5)

    df = pd.DataFrame(data)
    df.to_csv(output_dir / 'blob_storage_metrics.csv', index=False)
    print(f"  + Generated Blob Storage metrics: {len(df)} records")

def generate_api_metrics(output_dir: Path):
    """Generate API Performance metrics"""
    timestamps = generate_timestamps('2026-01-14 00:00:00', duration_hours=24, interval_seconds=60)

    endpoints = ['/api/users', '/api/orders', '/api/products', '/api/analytics', '/api/search']

    data = {
        'timestamp': timestamps,
        'endpoint': np.random.choice(endpoints, len(timestamps)),
        'method': np.random.choice(['GET', 'POST', 'PUT', 'DELETE'], len(timestamps), p=[0.6, 0.25, 0.1, 0.05]),
        'status_code': np.random.choice([200, 201, 400, 404, 500], len(timestamps), p=[0.85, 0.08, 0.03, 0.02, 0.02]),
        'response_time_ms': np.random.exponential(120, len(timestamps)),
        'request_size_bytes': np.random.exponential(2048, len(timestamps)),
        'response_size_bytes': np.random.exponential(8192, len(timestamps)),
        'requests_per_minute': np.random.poisson(150, len(timestamps)),
        'error_count': np.random.poisson(3, len(timestamps)),
        'timeout_count': np.random.poisson(1, len(timestamps)),
        'user_count': np.random.poisson(50, len(timestamps)),
        'cache_hit_ratio': np.random.uniform(0.65, 0.95, len(timestamps))
    }

    # Add peak traffic period with degraded performance
    peak_start = len(timestamps) // 3
    peak_end = peak_start + 60
    data['requests_per_minute'][peak_start:peak_end] = np.random.poisson(500, peak_end - peak_start)
    data['response_time_ms'][peak_start:peak_end] = np.random.exponential(450, peak_end - peak_start)
    data['error_count'][peak_start:peak_end] = np.random.poisson(25, peak_end - peak_start)

    df = pd.DataFrame(data)
    df.to_excel(output_dir / 'api_performance_metrics.xlsx', index=False)
    print(f"  + Generated API Performance metrics: {len(df)} records")

def generate_redis_metrics(output_dir: Path):
    """Generate Redis Cache metrics"""
    timestamps = generate_timestamps('2026-01-14 00:00:00', duration_hours=24, interval_seconds=120)

    data = {
        'timestamp': timestamps,
        'cache_name': 'redis-cache-prod',
        'server_load_percent': np.random.normal(35, 10, len(timestamps)).clip(0, 100),
        'memory_used_mb': np.random.normal(3072, 512, len(timestamps)).clip(100, 5120),
        'memory_limit_mb': 5120,
        'memory_fragmentation_ratio': np.random.normal(1.2, 0.1, len(timestamps)).clip(1.0, 2.0),
        'connected_clients': np.random.poisson(100, len(timestamps)),
        'blocked_clients': np.random.poisson(2, len(timestamps)),
        'total_commands_per_sec': np.random.poisson(5000, len(timestamps)),
        'cache_hits_per_sec': np.random.poisson(4500, len(timestamps)),
        'cache_misses_per_sec': np.random.poisson(500, len(timestamps)),
        'evicted_keys': np.random.poisson(10, len(timestamps)),
        'expired_keys': np.random.poisson(50, len(timestamps)),
        'keyspace_size': np.random.normal(1000000, 50000, len(timestamps)).astype(int),
        'avg_ttl_seconds': np.random.normal(3600, 600, len(timestamps)),
        'network_input_kbps': np.random.exponential(1024, len(timestamps)),
        'network_output_kbps': np.random.exponential(2048, len(timestamps))
    }

    # Calculate hit rate
    data['cache_hit_rate'] = data['cache_hits_per_sec'] / (data['cache_hits_per_sec'] + data['cache_misses_per_sec'])

    # Add cache inefficiency period
    inefficient_start = len(timestamps) // 4
    inefficient_end = inefficient_start + 30
    data['cache_misses_per_sec'][inefficient_start:inefficient_end] = np.random.poisson(2000, inefficient_end - inefficient_start)
    data['cache_hit_rate'][inefficient_start:inefficient_end] = np.random.uniform(0.3, 0.5, inefficient_end - inefficient_start)
    data['evicted_keys'][inefficient_start:inefficient_end] = np.random.poisson(100, inefficient_end - inefficient_start)

    df = pd.DataFrame(data)
    df.to_csv(output_dir / 'redis_cache_metrics.csv', index=False)
    print(f"  + Generated Redis Cache metrics: {len(df)} records")

def generate_sample_data(output_dir: Path):
    """Generate all sample Azure metrics data

    Args:
        output_dir: Directory to save generated files
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    print("\nGenerating sample Azure metrics data...")
    generate_aks_metrics(output_dir)
    generate_sql_metrics(output_dir)
    generate_blob_metrics(output_dir)
    generate_api_metrics(output_dir)
    generate_redis_metrics(output_dir)
    print(f"\nAll sample data generated successfully in: {output_dir}\n")
