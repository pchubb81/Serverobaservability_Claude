"""
Logging utility for the observability system
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from colorama import Fore, Style

class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors for different log levels"""

    COLORS = {
        'DEBUG': Fore.BLUE,
        'INFO': Fore.GREEN,
        'WARNING': Fore.YELLOW,
        'ERROR': Fore.RED,
        'CRITICAL': Fore.RED + Style.BRIGHT,
    }

    def format(self, record):
        levelname = record.levelname
        if levelname in self.COLORS:
            record.levelname = f"{self.COLORS[levelname]}{levelname}{Style.RESET_ALL}"
        return super().format(record)

def setup_logger(name='ObservabilitySystem', verbose=False):
    """Setup and configure logger

    Args:
        name: Logger name
        verbose: Enable debug logging

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)

    # Set log level
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Remove existing handlers
    logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Colored formatter for console
    console_format = '%(asctime)s | %(levelname)s | %(message)s'
    console_formatter = ColoredFormatter(
        console_format,
        datefmt='%H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)

    # File handler
    log_dir = Path('./logs')
    log_dir.mkdir(exist_ok=True)

    log_file = log_dir / f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)

    # Plain formatter for file
    file_format = '%(asctime)s | %(levelname)s | %(name)s | %(message)s'
    file_formatter = logging.Formatter(file_format)
    file_handler.setFormatter(file_formatter)

    # Add handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger
