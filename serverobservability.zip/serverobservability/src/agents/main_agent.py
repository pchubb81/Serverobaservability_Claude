"""
Main Agent - Orchestrates all sub-agents and analysis
"""

import logging
from pathlib import Path
from typing import Dict, Any
from datetime import datetime

from .aks_agent import AKSAgent
from .sql_agent import SQLAgent
from .blob_agent import BlobAgent
from .api_agent import APIAgent
from .redis_agent import RedisAgent
from ..analyzers.correlation_engine import CorrelationEngine

class MainAgent:
    """Main orchestrator agent for Azure observability analysis"""

    def __init__(self, data_dir: str, output_dir: str, report_type: str = 'both', output_format: str = 'html'):
        """Initialize main agent

        Args:
            data_dir: Directory containing metric files
            output_dir: Directory for output reports
            report_type: Type of report ('executive', 'technical', 'both')
            output_format: Output format ('html', 'pdf', 'both')
        """
        self.data_dir = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.report_type = report_type
        self.output_format = output_format
        self.logger = logging.getLogger("MainAgent")

        # Initialize sub-agents
        self.agents = {
            'AKS': AKSAgent(str(data_dir)),
            'SQLServer': SQLAgent(str(data_dir)),
            'BlobStorage': BlobAgent(str(data_dir)),
            'API': APIAgent(str(data_dir)),
            'RedisCache': RedisAgent(str(data_dir))
        }

        # Initialize correlation engine
        self.correlation_engine = CorrelationEngine()

        self.results = {}

    def analyze(self) -> Dict[str, Any]:
        """Run complete analysis across all services

        Returns:
            Dictionary containing all analysis results
        """
        self.logger.info("Starting multi-service analysis...")

        # Load and analyze each service
        for agent_name, agent in self.agents.items():
            self.logger.info(f"Analyzing {agent_name}...")
            try:
                # Load data
                if agent.load_data():
                    # Perform analysis
                    result = agent.analyze()
                    self.results[agent_name] = result
                    self.logger.info(f"{agent_name} analysis complete - Health Score: {result.get('health_score', 'N/A')}")
                else:
                    self.logger.warning(f"No data found for {agent_name}")
                    self.results[agent_name] = {}
            except Exception as e:
                self.logger.error(f"Error analyzing {agent_name}: {e}", exc_info=True)
                self.results[agent_name] = {}

        # Perform correlation analysis
        self.logger.info("Performing cross-service correlation analysis...")
        try:
            correlation_results = self.correlation_engine.analyze_correlations(self.results)
            self.results['correlation_analysis'] = correlation_results
            self.logger.info(f"Found {len(correlation_results.get('correlations', []))} correlations and "
                           f"{len(correlation_results.get('bottlenecks', []))} bottlenecks")
        except Exception as e:
            self.logger.error(f"Error in correlation analysis: {e}", exc_info=True)
            self.results['correlation_analysis'] = {}

        # Generate summary
        self.results['summary'] = self._generate_summary()

        return self.results

    def _generate_summary(self) -> Dict[str, Any]:
        """Generate overall summary of analysis"""
        services_analyzed = sum(1 for r in self.results.values() if isinstance(r, dict) and r.get('metrics'))

        total_anomalies = 0
        critical_issues = []

        for service, result in self.results.items():
            if service == 'correlation_analysis':
                continue
            if isinstance(result, dict) and 'anomalies' in result:
                anomalies = result['anomalies']
                total_anomalies += len(anomalies)

                # Collect critical issues
                for anomaly in anomalies:
                    if anomaly.get('severity') in ['critical', 'high']:
                        critical_issues.append({
                            'service': service,
                            'type': anomaly.get('type'),
                            'severity': anomaly.get('severity'),
                            'description': anomaly.get('description')
                        })

        # Get system health
        correlation_results = self.results.get('correlation_analysis', {})
        system_health = correlation_results.get('system_health', {})
        bottlenecks = correlation_results.get('bottlenecks', [])

        return {
            'analysis_timestamp': datetime.now().isoformat(),
            'services_analyzed': services_analyzed,
            'total_anomalies': total_anomalies,
            'critical_issues_count': len(critical_issues),
            'critical_issues': critical_issues[:10],  # Top 10
            'bottlenecks_count': len(bottlenecks),
            'bottlenecks': bottlenecks,
            'health_score': system_health.get('overall_score', 'N/A'),
            'system_status': system_health.get('overall_status', 'unknown'),
            'services_healthy': system_health.get('services_healthy', 0),
            'services_warning': system_health.get('services_warning', 0),
            'services_degraded': system_health.get('services_degraded', 0),
            'services_critical': system_health.get('services_critical', 0)
        }

    def generate_reports(self, results: Dict[str, Any]) -> Dict[str, str]:
        """Generate reports and visualizations

        Args:
            results: Analysis results

        Returns:
            Dictionary of report paths
        """
        from ..reporters.executive_report import ExecutiveReportGenerator
        from ..reporters.technical_report import TechnicalReportGenerator
        from ..visualizers.dashboard_generator import DashboardGenerator

        report_paths = {}

        try:
            # Generate executive report
            if self.report_type in ['executive', 'both']:
                self.logger.info("Generating executive summary report...")
                exec_gen = ExecutiveReportGenerator(self.output_dir)
                exec_path = exec_gen.generate(results, self.output_format)
                report_paths['Executive Summary'] = exec_path

            # Generate technical report
            if self.report_type in ['technical', 'both']:
                self.logger.info("Generating technical report...")
                tech_gen = TechnicalReportGenerator(self.output_dir)
                tech_path = tech_gen.generate(results, self.output_format)
                report_paths['Technical Report'] = tech_path

            # Generate dashboard
            self.logger.info("Generating interactive dashboard...")
            dash_gen = DashboardGenerator(self.output_dir)
            dash_path = dash_gen.generate(results)
            report_paths['Interactive Dashboard'] = dash_path

        except Exception as e:
            self.logger.error(f"Error generating reports: {e}", exc_info=True)

        return report_paths
