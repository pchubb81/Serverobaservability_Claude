"""
Redis Cache Agent
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from pathlib import Path

from .base_agent import BaseAgent

class RedisAgent(BaseAgent):
    """Agent for analyzing Redis Cache metrics"""

    def __init__(self, data_dir: str):
        super().__init__("RedisCache", data_dir)
        self.thresholds = {
            'server_load_percent': 70,
            'memory_percent': 80,
            'cache_hit_rate': 0.90,
            'blocked_clients': 5,
            'evicted_keys_rate': 100
        }

    def load_data(self) -> bool:
        """Load Redis Cache metrics from CSV files"""
        try:
            csv_files = list(self.data_dir.glob('*redis*.csv'))
            if not csv_files:
                self.logger.warning("No Redis Cache CSV files found")
                return False

            self.logger.info(f"Loading Redis data from {csv_files[0]}")
            self.data = pd.read_csv(csv_files[0])
            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'])

            # Calculate memory percentage if not present
            if 'memory_used_mb' in self.data.columns and 'memory_limit_mb' in self.data.columns:
                self.data['memory_percent'] = (
                    self.data['memory_used_mb'] / self.data['memory_limit_mb'] * 100
                )

            return True

        except Exception as e:
            self.logger.error(f"Failed to load Redis data: {e}")
            return False

    def analyze(self) -> Dict[str, Any]:
        """Analyze Redis Cache metrics"""
        if self.data is None or self.data.empty:
            return {}

        self.logger.info("Analyzing Redis Cache metrics...")

        # Calculate key metrics
        self.metrics = {
            'avg_server_load_percent': float(self.data['server_load_percent'].mean()),
            'max_server_load_percent': float(self.data['server_load_percent'].max()),
            'p95_server_load_percent': float(self.data['server_load_percent'].quantile(0.95)),
            'avg_memory_percent': float(self.data['memory_percent'].mean()),
            'max_memory_percent': float(self.data['memory_percent'].max()),
            'p95_memory_percent': float(self.data['memory_percent'].quantile(0.95)),
            'avg_memory_fragmentation': float(self.data['memory_fragmentation_ratio'].mean()),
            'avg_connected_clients': float(self.data['connected_clients'].mean()),
            'max_connected_clients': int(self.data['connected_clients'].max()),
            'total_blocked_clients': int(self.data['blocked_clients'].sum()),
            'avg_commands_per_sec': float(self.data['total_commands_per_sec'].mean()),
            'max_commands_per_sec': int(self.data['total_commands_per_sec'].max()),
            'avg_cache_hit_rate': float(self.data['cache_hit_rate'].mean()),
            'min_cache_hit_rate': float(self.data['cache_hit_rate'].min()),
            'total_evicted_keys': int(self.data['evicted_keys'].sum()),
            'total_expired_keys': int(self.data['expired_keys'].sum()),
            'avg_keyspace_size': int(self.data['keyspace_size'].mean()),
            'avg_network_input_kbps': float(self.data['network_input_kbps'].mean()),
            'avg_network_output_kbps': float(self.data['network_output_kbps'].mean())
        }

        # Calculate hit/miss rates
        total_hits = self.data['cache_hits_per_sec'].sum()
        total_misses = self.data['cache_misses_per_sec'].sum()
        self.metrics['overall_hit_rate'] = total_hits / (total_hits + total_misses) if (total_hits + total_misses) > 0 else 0

        # Detect anomalies
        self.anomalies = self.detect_anomalies()

        # Generate insights
        self.insights = self.get_insights()

        # Calculate health score
        health_score = self.calculate_health_score(
            {
                'load': self.metrics['p95_server_load_percent'],
                'memory': self.metrics['p95_memory_percent'],
                'hit_rate': 100 - (self.metrics['avg_cache_hit_rate'] * 100),
                'evictions': self.metrics['total_evicted_keys']
            },
            {
                'load': self.thresholds['server_load_percent'],
                'memory': self.thresholds['memory_percent'],
                'hit_rate': 100 - (self.thresholds['cache_hit_rate'] * 100),
                'evictions': self.thresholds['evicted_keys_rate']
            }
        )

        return {
            'service': 'RedisCache',
            'metrics': self.metrics,
            'anomalies': self.anomalies,
            'insights': self.insights,
            'health_score': health_score,
            'time_series_data': self.data.to_dict('records')
        }

    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in Redis metrics"""
        anomalies = []

        # High server load
        high_load = self.data[self.data['server_load_percent'] > self.thresholds['server_load_percent']]
        if len(high_load) > 0:
            anomalies.append({
                'type': 'High Server Load',
                'severity': 'high' if high_load['server_load_percent'].mean() > 85 else 'medium',
                'count': len(high_load),
                'description': f"{len(high_load)} instances of server load above {self.thresholds['server_load_percent']}%",
                'max_value': float(high_load['server_load_percent'].max()),
                'avg_value': float(high_load['server_load_percent'].mean())
            })

        # High memory usage
        high_memory = self.data[self.data['memory_percent'] > self.thresholds['memory_percent']]
        if len(high_memory) > 0:
            anomalies.append({
                'type': 'High Memory Usage',
                'severity': 'critical' if high_memory['memory_percent'].mean() > 95 else 'high',
                'count': len(high_memory),
                'description': f"{len(high_memory)} instances of memory usage above {self.thresholds['memory_percent']}%",
                'max_value': float(high_memory['memory_percent'].max())
            })

        # Low cache hit rate
        low_hit_rate = self.data[self.data['cache_hit_rate'] < self.thresholds['cache_hit_rate']]
        if len(low_hit_rate) > 0:
            anomalies.append({
                'type': 'Low Cache Hit Rate',
                'severity': 'high' if low_hit_rate['cache_hit_rate'].mean() < 0.7 else 'medium',
                'count': len(low_hit_rate),
                'description': f"{len(low_hit_rate)} instances of hit rate below {self.thresholds['cache_hit_rate']*100:.0f}%",
                'min_value': float(low_hit_rate['cache_hit_rate'].min()),
                'avg_value': float(low_hit_rate['cache_hit_rate'].mean())
            })

        # Key evictions
        if self.metrics['total_evicted_keys'] > self.thresholds['evicted_keys_rate']:
            high_eviction = self.data[self.data['evicted_keys'] > 0]
            anomalies.append({
                'type': 'High Key Evictions',
                'severity': 'high',
                'count': len(high_eviction),
                'description': f"{self.metrics['total_evicted_keys']} keys evicted due to memory pressure",
                'note': 'Indicates insufficient memory or inappropriate maxmemory-policy'
            })

        # Blocked clients
        if self.metrics['total_blocked_clients'] > self.thresholds['blocked_clients']:
            blocked = self.data[self.data['blocked_clients'] > 0]
            anomalies.append({
                'type': 'Blocked Clients',
                'severity': 'medium',
                'count': len(blocked),
                'description': f"{self.metrics['total_blocked_clients']} client blocking incidents",
                'max_concurrent': int(self.data['blocked_clients'].max())
            })

        # Memory fragmentation
        high_fragmentation = self.data[self.data['memory_fragmentation_ratio'] > 1.5]
        if len(high_fragmentation) > len(self.data) * 0.2:
            anomalies.append({
                'type': 'Memory Fragmentation',
                'severity': 'medium',
                'count': len(high_fragmentation),
                'description': f"Memory fragmentation ratio averaging {self.metrics['avg_memory_fragmentation']:.2f}",
                'note': 'Consider activedefrag or restart during maintenance window'
            })

        return anomalies

    def get_insights(self) -> List[str]:
        """Generate actionable insights"""
        insights = []

        # Cache hit rate insights
        if self.metrics['avg_cache_hit_rate'] < self.thresholds['cache_hit_rate']:
            insights.append(
                f"⚠️ Cache hit rate is {self.metrics['avg_cache_hit_rate']*100:.1f}%. "
                f"Review caching patterns and key TTLs to improve efficiency."
            )

        # Memory insights
        if self.metrics['p95_memory_percent'] > self.thresholds['memory_percent']:
            insights.append(
                f"🔴 Memory usage is critically high (P95: {self.metrics['p95_memory_percent']:.1f}%). "
                f"Scale up Redis instance or optimize data structures."
            )

        # Eviction insights
        if self.metrics['total_evicted_keys'] > self.thresholds['evicted_keys_rate']:
            eviction_rate = self.metrics['total_evicted_keys'] / len(self.data)
            insights.append(
                f"⚠️ {self.metrics['total_evicted_keys']} keys evicted (avg {eviction_rate:.1f}/minute). "
                f"Increase maxmemory or review maxmemory-policy."
            )

        # Server load insights
        if self.metrics['p95_server_load_percent'] > self.thresholds['server_load_percent']:
            insights.append(
                f"⚠️ Server load is high (P95: {self.metrics['p95_server_load_percent']:.1f}%). "
                f"Consider Redis clustering or read replicas."
            )

        # Fragmentation insights
        if self.metrics['avg_memory_fragmentation'] > 1.5:
            insights.append(
                f"⚠️ Memory fragmentation ratio is {self.metrics['avg_memory_fragmentation']:.2f}. "
                f"Enable active defragmentation (activedefrag yes)."
            )

        # Blocked clients
        if self.metrics['total_blocked_clients'] > self.thresholds['blocked_clients']:
            insights.append(
                f"⚠️ {self.metrics['total_blocked_clients']} client blocking events. "
                f"Review blocking operations (BLPOP, BRPOP) and timeouts."
            )

        # Connection insights
        if self.metrics['max_connected_clients'] > 1000:
            insights.append(
                f"📊 High connection count (max: {self.metrics['max_connected_clients']}). "
                f"Review connection pooling and idle connection cleanup."
            )

        # Throughput insights
        if self.metrics['avg_commands_per_sec'] < 100:
            insights.append(
                f"📊 Low command throughput ({self.metrics['avg_commands_per_sec']:.0f} ops/sec). "
                f"Cache may be underutilized."
            )

        # Positive insights
        if self.metrics['avg_cache_hit_rate'] > 0.95:
            insights.append(f"✅ Excellent cache hit rate ({self.metrics['avg_cache_hit_rate']*100:.1f}%).")

        if self.metrics['p95_memory_percent'] < 70 and self.metrics['total_evicted_keys'] == 0:
            insights.append("✅ Redis memory management is healthy with no evictions.")

        if self.metrics['avg_memory_fragmentation'] < 1.3:
            insights.append("✅ Memory fragmentation is well-controlled.")

        return insights
