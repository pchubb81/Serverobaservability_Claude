"""
Base Agent class for Azure service analysis
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, List
import pandas as pd
import logging

class BaseAgent(ABC):
    """Base class for all service-specific agents"""

    def __init__(self, name: str, data_dir: str):
        """Initialize base agent

        Args:
            name: Agent name
            data_dir: Directory containing data files
        """
        self.name = name
        self.data_dir = Path(data_dir)
        self.logger = logging.getLogger(f"Agent.{name}")
        self.data = None
        self.metrics = {}
        self.anomalies = []
        self.insights = []

    @abstractmethod
    def load_data(self) -> bool:
        """Load data from files

        Returns:
            True if data loaded successfully
        """
        pass

    @abstractmethod
    def analyze(self) -> Dict[str, Any]:
        """Perform analysis on loaded data

        Returns:
            Dictionary containing analysis results
        """
        pass

    @abstractmethod
    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in the data

        Returns:
            List of detected anomalies
        """
        pass

    @abstractmethod
    def get_insights(self) -> List[str]:
        """Generate actionable insights

        Returns:
            List of insight strings
        """
        pass

    def get_summary(self) -> Dict[str, Any]:
        """Get agent summary

        Returns:
            Summary dictionary
        """
        return {
            'agent': self.name,
            'data_loaded': self.data is not None,
            'metrics': self.metrics,
            'anomaly_count': len(self.anomalies),
            'insights': self.insights
        }

    def calculate_health_score(self, metrics: Dict[str, float], thresholds: Dict[str, float]) -> float:
        """Calculate health score based on metrics and thresholds

        Args:
            metrics: Dictionary of metric values
            thresholds: Dictionary of threshold values

        Returns:
            Health score (0-100)
        """
        scores = []

        for metric, value in metrics.items():
            if metric in thresholds:
                threshold = thresholds[metric]
                # Higher is worse for most metrics
                if value <= threshold:
                    scores.append(100)
                elif value <= threshold * 1.5:
                    scores.append(70)
                elif value <= threshold * 2:
                    scores.append(40)
                else:
                    scores.append(20)

        return sum(scores) / len(scores) if scores else 100

    def identify_trends(self, series: pd.Series, window: int = 10) -> str:
        """Identify trend in time series

        Args:
            series: Time series data
            window: Rolling window size

        Returns:
            Trend description
        """
        if len(series) < window:
            return "insufficient_data"

        rolling_mean = series.rolling(window=window).mean()
        first_half = rolling_mean[:len(rolling_mean)//2].mean()
        second_half = rolling_mean[len(rolling_mean)//2:].mean()

        change_percent = ((second_half - first_half) / first_half) * 100 if first_half > 0 else 0

        if abs(change_percent) < 5:
            return "stable"
        elif change_percent > 0:
            return f"increasing ({change_percent:.1f}%)"
        else:
            return f"decreasing ({abs(change_percent):.1f}%)"
