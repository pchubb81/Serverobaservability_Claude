"""
AKS (Azure Kubernetes Service) Agent
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from pathlib import Path

from .base_agent import BaseAgent

class AKSAgent(BaseAgent):
    """Agent for analyzing AKS metrics"""

    def __init__(self, data_dir: str):
        super().__init__("AKS", data_dir)
        self.thresholds = {
            'cpu_usage_percent': 80,
            'memory_usage_percent': 85,
            'restart_count': 3,
            'pod_failures': 5
        }

    def load_data(self) -> bool:
        """Load AKS metrics from CSV files"""
        try:
            csv_files = list(self.data_dir.glob('*aks*.csv'))
            if not csv_files:
                self.logger.warning("No AKS CSV files found")
                return False

            self.logger.info(f"Loading AKS data from {csv_files[0]}")
            self.data = pd.read_csv(csv_files[0])
            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'])

            # Calculate memory percentage
            if 'memory_usage_mb' in self.data.columns and 'memory_limit_mb' in self.data.columns:
                self.data['memory_usage_percent'] = (
                    self.data['memory_usage_mb'] / self.data['memory_limit_mb'] * 100
                )

            return True

        except Exception as e:
            self.logger.error(f"Failed to load AKS data: {e}")
            return False

    def analyze(self) -> Dict[str, Any]:
        """Analyze AKS metrics"""
        if self.data is None or self.data.empty:
            return {}

        self.logger.info("Analyzing AKS metrics...")

        # Calculate key metrics
        self.metrics = {
            'avg_cpu_usage': float(self.data['cpu_usage_percent'].mean()),
            'max_cpu_usage': float(self.data['cpu_usage_percent'].max()),
            'p95_cpu_usage': float(self.data['cpu_usage_percent'].quantile(0.95)),
            'avg_memory_usage': float(self.data['memory_usage_percent'].mean()),
            'max_memory_usage': float(self.data['memory_usage_percent'].max()),
            'p95_memory_usage': float(self.data['memory_usage_percent'].quantile(0.95)),
            'total_restarts': int(self.data['restart_count'].sum()),
            'unique_pods': int(self.data['pod_name'].nunique()),
            'unique_nodes': int(self.data['node_name'].nunique()),
            'failed_pods': int((self.data['pod_status'] != 'Running').sum()),
            'avg_network_rx_mb': float(self.data['network_rx_bytes'].mean() / 1024 / 1024),
            'avg_network_tx_mb': float(self.data['network_tx_bytes'].mean() / 1024 / 1024)
        }

        # Detect anomalies
        self.anomalies = self.detect_anomalies()

        # Generate insights
        self.insights = self.get_insights()

        # Calculate health score
        health_score = self.calculate_health_score(
            {
                'cpu': self.metrics['p95_cpu_usage'],
                'memory': self.metrics['p95_memory_usage'],
                'restarts': self.metrics['total_restarts']
            },
            {
                'cpu': self.thresholds['cpu_usage_percent'],
                'memory': self.thresholds['memory_usage_percent'],
                'restarts': self.thresholds['restart_count']
            }
        )

        # Pod-level analysis
        pod_analysis = self.data.groupby('pod_name').agg({
            'cpu_usage_percent': ['mean', 'max'],
            'memory_usage_percent': ['mean', 'max'],
            'restart_count': 'sum'
        }).round(2)

        # Node-level analysis
        node_analysis = self.data.groupby('node_name').agg({
            'cpu_usage_percent': ['mean', 'max'],
            'memory_usage_percent': ['mean', 'max'],
            'pod_name': 'count'
        }).round(2)

        return {
            'service': 'AKS',
            'metrics': self.metrics,
            'anomalies': self.anomalies,
            'insights': self.insights,
            'health_score': health_score,
            'pod_analysis': pod_analysis.to_dict(),
            'node_analysis': node_analysis.to_dict(),
            'time_series_data': self.data.to_dict('records')
        }

    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in AKS metrics"""
        anomalies = []

        # High CPU usage
        high_cpu = self.data[self.data['cpu_usage_percent'] > self.thresholds['cpu_usage_percent']]
        if len(high_cpu) > 0:
            anomalies.append({
                'type': 'High CPU Usage',
                'severity': 'high' if high_cpu['cpu_usage_percent'].mean() > 90 else 'medium',
                'count': len(high_cpu),
                'description': f"{len(high_cpu)} instances of CPU usage above {self.thresholds['cpu_usage_percent']}%",
                'max_value': float(high_cpu['cpu_usage_percent'].max()),
                'affected_pods': high_cpu['pod_name'].unique().tolist()[:5]
            })

        # High memory usage
        high_memory = self.data[self.data['memory_usage_percent'] > self.thresholds['memory_usage_percent']]
        if len(high_memory) > 0:
            anomalies.append({
                'type': 'High Memory Usage',
                'severity': 'high' if high_memory['memory_usage_percent'].mean() > 95 else 'medium',
                'count': len(high_memory),
                'description': f"{len(high_memory)} instances of memory usage above {self.thresholds['memory_usage_percent']}%",
                'max_value': float(high_memory['memory_usage_percent'].max()),
                'affected_pods': high_memory['pod_name'].unique().tolist()[:5]
            })

        # Pod restarts
        restart_pods = self.data.groupby('pod_name')['restart_count'].sum()
        problematic_pods = restart_pods[restart_pods > self.thresholds['restart_count']]
        if len(problematic_pods) > 0:
            anomalies.append({
                'type': 'Excessive Pod Restarts',
                'severity': 'high',
                'count': len(problematic_pods),
                'description': f"{len(problematic_pods)} pods with more than {self.thresholds['restart_count']} restarts",
                'affected_pods': problematic_pods.index.tolist(),
                'restart_counts': problematic_pods.to_dict()
            })

        # Failed pods
        failed = self.data[self.data['pod_status'] != 'Running']
        if len(failed) > 0:
            anomalies.append({
                'type': 'Pod Failures',
                'severity': 'critical',
                'count': len(failed),
                'description': f"{len(failed)} pod failure instances detected",
                'affected_pods': failed['pod_name'].unique().tolist()
            })

        return anomalies

    def get_insights(self) -> List[str]:
        """Generate actionable insights"""
        insights = []

        # CPU insights
        if self.metrics['p95_cpu_usage'] > self.thresholds['cpu_usage_percent']:
            insights.append(
                f"⚠️ CPU usage frequently exceeds threshold (P95: {self.metrics['p95_cpu_usage']:.1f}%). "
                f"Consider scaling horizontally or optimizing workloads."
            )

        # Memory insights
        if self.metrics['p95_memory_usage'] > self.thresholds['memory_usage_percent']:
            insights.append(
                f"⚠️ Memory usage is critically high (P95: {self.metrics['p95_memory_usage']:.1f}%). "
                f"Review memory limits and potential memory leaks."
            )

        # Restart insights
        if self.metrics['total_restarts'] > self.thresholds['restart_count']:
            insights.append(
                f"⚠️ Total of {self.metrics['total_restarts']} pod restarts detected. "
                f"Investigate application stability and health checks."
            )

        # Resource distribution
        if self.metrics['unique_nodes'] > 0:
            pods_per_node = self.metrics['unique_pods'] / self.metrics['unique_nodes']
            if pods_per_node > 20:
                insights.append(
                    f"📊 High pod density ({pods_per_node:.1f} pods/node). "
                    f"Consider adding more nodes for better resource distribution."
                )

        # Positive insights
        if self.metrics['p95_cpu_usage'] < 60 and self.metrics['p95_memory_usage'] < 70:
            insights.append("✅ Resource utilization is healthy with room for growth.")

        if self.metrics['total_restarts'] == 0:
            insights.append("✅ No pod restarts detected - excellent stability.")

        return insights
