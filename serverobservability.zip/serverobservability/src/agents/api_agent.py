"""
API Performance Agent
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from pathlib import Path

from .base_agent import BaseAgent

class APIAgent(BaseAgent):
    """Agent for analyzing API performance metrics"""

    def __init__(self, data_dir: str):
        super().__init__("API", data_dir)
        self.thresholds = {
            'response_time_ms': 200,
            'error_rate_percent': 2,
            'timeout_rate_percent': 1,
            'cache_hit_ratio': 0.70
        }

    def load_data(self) -> bool:
        """Load API metrics from Excel/CSV files"""
        try:
            # Try Excel first
            excel_files = list(self.data_dir.glob('*api*.xlsx'))
            if excel_files:
                self.logger.info(f"Loading API data from {excel_files[0]}")
                self.data = pd.read_excel(excel_files[0])
            else:
                # Try CSV
                csv_files = list(self.data_dir.glob('*api*.csv'))
                if csv_files:
                    self.logger.info(f"Loading API data from {csv_files[0]}")
                    self.data = pd.read_csv(csv_files[0])
                else:
                    self.logger.warning("No API files found")
                    return False

            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'])

            # Calculate error rate
            total_requests = len(self.data)
            error_requests = len(self.data[self.data['status_code'] >= 400])
            self.data['is_error'] = self.data['status_code'] >= 400

            return True

        except Exception as e:
            self.logger.error(f"Failed to load API data: {e}")
            return False

    def analyze(self) -> Dict[str, Any]:
        """Analyze API performance metrics"""
        if self.data is None or self.data.empty:
            return {}

        self.logger.info("Analyzing API performance metrics...")

        # Calculate key metrics
        total_requests = len(self.data)
        error_requests = self.data['is_error'].sum()
        success_requests = total_requests - error_requests

        self.metrics = {
            'total_requests': total_requests,
            'success_requests': int(success_requests),
            'error_requests': int(error_requests),
            'error_rate_percent': float(error_requests / total_requests * 100) if total_requests > 0 else 0,
            'avg_response_time_ms': float(self.data['response_time_ms'].mean()),
            'median_response_time_ms': float(self.data['response_time_ms'].median()),
            'p95_response_time_ms': float(self.data['response_time_ms'].quantile(0.95)),
            'p99_response_time_ms': float(self.data['response_time_ms'].quantile(0.99)),
            'max_response_time_ms': float(self.data['response_time_ms'].max()),
            'total_timeouts': int(self.data['timeout_count'].sum()),
            'avg_cache_hit_ratio': float(self.data['cache_hit_ratio'].mean()),
            'avg_requests_per_minute': float(self.data['requests_per_minute'].mean()),
            'max_requests_per_minute': int(self.data['requests_per_minute'].max()),
            'unique_endpoints': int(self.data['endpoint'].nunique()),
            'unique_users': int(self.data['user_count'].sum())
        }

        # Detect anomalies
        self.anomalies = self.detect_anomalies()

        # Generate insights
        self.insights = self.get_insights()

        # Calculate health score
        health_score = self.calculate_health_score(
            {
                'response_time': self.metrics['p95_response_time_ms'],
                'error_rate': self.metrics['error_rate_percent'],
                'cache': 100 - (self.metrics['avg_cache_hit_ratio'] * 100)
            },
            {
                'response_time': self.thresholds['response_time_ms'],
                'error_rate': self.thresholds['error_rate_percent'],
                'cache': 100 - (self.thresholds['cache_hit_ratio'] * 100)
            }
        )

        # Endpoint-level analysis
        endpoint_analysis = self.data.groupby('endpoint').agg({
            'response_time_ms': ['mean', 'median', 'max', 'count'],
            'is_error': 'sum',
            'status_code': lambda x: (x >= 400).sum()
        }).round(2).to_dict()

        # Status code distribution
        status_distribution = self.data['status_code'].value_counts().to_dict()

        # Method distribution
        method_distribution = self.data.groupby('method').agg({
            'response_time_ms': 'mean',
            'is_error': 'sum'
        }).round(2).to_dict()

        return {
            'service': 'API',
            'metrics': self.metrics,
            'anomalies': self.anomalies,
            'insights': self.insights,
            'health_score': health_score,
            'endpoint_analysis': endpoint_analysis,
            'status_distribution': status_distribution,
            'method_distribution': method_distribution,
            'time_series_data': self.data.to_dict('records')
        }

    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in API metrics"""
        anomalies = []

        # Slow responses
        slow_responses = self.data[self.data['response_time_ms'] > self.thresholds['response_time_ms']]
        if len(slow_responses) > 0:
            anomalies.append({
                'type': 'Slow API Responses',
                'severity': 'high' if slow_responses['response_time_ms'].mean() > 1000 else 'medium',
                'count': len(slow_responses),
                'description': f"{len(slow_responses)} requests slower than {self.thresholds['response_time_ms']}ms",
                'max_value': float(slow_responses['response_time_ms'].max()),
                'avg_value': float(slow_responses['response_time_ms'].mean()),
                'affected_endpoints': slow_responses['endpoint'].value_counts().head(5).to_dict()
            })

        # High error rate
        if self.metrics['error_rate_percent'] > self.thresholds['error_rate_percent']:
            error_data = self.data[self.data['is_error']]
            anomalies.append({
                'type': 'High Error Rate',
                'severity': 'critical' if self.metrics['error_rate_percent'] > 10 else 'high',
                'count': int(self.metrics['error_requests']),
                'description': f"Error rate is {self.metrics['error_rate_percent']:.2f}%",
                'status_codes': error_data['status_code'].value_counts().to_dict(),
                'affected_endpoints': error_data['endpoint'].value_counts().head(5).to_dict()
            })

        # Timeouts
        if self.metrics['total_timeouts'] > 0:
            timeout_data = self.data[self.data['timeout_count'] > 0]
            anomalies.append({
                'type': 'Request Timeouts',
                'severity': 'high',
                'count': self.metrics['total_timeouts'],
                'description': f"{self.metrics['total_timeouts']} timeout incidents detected",
                'affected_endpoints': timeout_data['endpoint'].unique().tolist()[:5]
            })

        # Low cache hit ratio
        low_cache = self.data[self.data['cache_hit_ratio'] < self.thresholds['cache_hit_ratio']]
        if len(low_cache) > len(self.data) * 0.2:  # More than 20% of requests
            anomalies.append({
                'type': 'Low Cache Efficiency',
                'severity': 'medium',
                'count': len(low_cache),
                'description': f"Cache hit ratio below {self.thresholds['cache_hit_ratio']*100:.0f}% for {len(low_cache)} requests",
                'avg_hit_ratio': float(low_cache['cache_hit_ratio'].mean())
            })

        # Traffic spikes
        mean_rpm = self.data['requests_per_minute'].mean()
        std_rpm = self.data['requests_per_minute'].std()
        spike_threshold = mean_rpm + (3 * std_rpm)
        spikes = self.data[self.data['requests_per_minute'] > spike_threshold]
        if len(spikes) > 0:
            anomalies.append({
                'type': 'Traffic Spikes',
                'severity': 'medium',
                'count': len(spikes),
                'description': f"{len(spikes)} traffic spike events detected",
                'max_rpm': int(spikes['requests_per_minute'].max()),
                'baseline_rpm': float(mean_rpm)
            })

        return anomalies

    def get_insights(self) -> List[str]:
        """Generate actionable insights"""
        insights = []

        # Response time insights
        if self.metrics['p95_response_time_ms'] > self.thresholds['response_time_ms']:
            insights.append(
                f"⚠️ API response times are elevated (P95: {self.metrics['p95_response_time_ms']:.0f}ms). "
                f"Review slow endpoints and database queries."
            )

        # Error rate insights
        if self.metrics['error_rate_percent'] > self.thresholds['error_rate_percent']:
            insights.append(
                f"🔴 Error rate is {self.metrics['error_rate_percent']:.2f}% ({self.metrics['error_requests']} errors). "
                f"Investigate error patterns and implement better error handling."
            )

        # Cache insights
        if self.metrics['avg_cache_hit_ratio'] < self.thresholds['cache_hit_ratio']:
            insights.append(
                f"⚠️ Cache hit ratio is {self.metrics['avg_cache_hit_ratio']*100:.1f}%. "
                f"Review caching strategy and TTL settings."
            )

        # Timeout insights
        if self.metrics['total_timeouts'] > 0:
            timeout_rate = (self.metrics['total_timeouts'] / self.metrics['total_requests'] * 100)
            insights.append(
                f"⚠️ {self.metrics['total_timeouts']} timeouts detected ({timeout_rate:.2f}%). "
                f"Review timeout settings and optimize long-running operations."
            )

        # Traffic insights
        if self.metrics['max_requests_per_minute'] > self.metrics['avg_requests_per_minute'] * 3:
            insights.append(
                f"📊 Significant traffic variability detected (peak: {self.metrics['max_requests_per_minute']} RPM). "
                f"Consider auto-scaling and rate limiting."
            )

        # Performance variance
        if self.metrics['p99_response_time_ms'] > self.metrics['p95_response_time_ms'] * 2:
            insights.append(
                f"⚠️ High response time variance (P99: {self.metrics['p99_response_time_ms']:.0f}ms vs P95: {self.metrics['p95_response_time_ms']:.0f}ms). "
                f"Some requests experiencing significant delays."
            )

        # Positive insights
        if self.metrics['error_rate_percent'] < 1 and self.metrics['p95_response_time_ms'] < 200:
            insights.append("✅ Excellent API performance with low latency and error rates.")

        if self.metrics['avg_cache_hit_ratio'] > 0.85:
            insights.append(f"✅ Strong cache performance ({self.metrics['avg_cache_hit_ratio']*100:.1f}% hit rate).")

        return insights
