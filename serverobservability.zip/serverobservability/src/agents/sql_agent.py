"""
Azure SQL Server Agent
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from pathlib import Path

from .base_agent import BaseAgent

class SQLAgent(BaseAgent):
    """Agent for analyzing SQL Server metrics"""

    def __init__(self, data_dir: str):
        super().__init__("SQLServer", data_dir)
        self.thresholds = {
            'dtu_percent': 80,
            'cpu_percent': 75,
            'avg_query_time_ms': 300,
            'blocked_connections': 5,
            'deadlocks': 2
        }

    def load_data(self) -> bool:
        """Load SQL Server metrics from Excel/CSV files"""
        try:
            # Try Excel first
            excel_files = list(self.data_dir.glob('*sql*.xlsx'))
            if excel_files:
                self.logger.info(f"Loading SQL data from {excel_files[0]}")
                self.data = pd.read_excel(excel_files[0])
            else:
                # Try CSV
                csv_files = list(self.data_dir.glob('*sql*.csv'))
                if csv_files:
                    self.logger.info(f"Loading SQL data from {csv_files[0]}")
                    self.data = pd.read_csv(csv_files[0])
                else:
                    self.logger.warning("No SQL Server files found")
                    return False

            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'])
            return True

        except Exception as e:
            self.logger.error(f"Failed to load SQL data: {e}")
            return False

    def analyze(self) -> Dict[str, Any]:
        """Analyze SQL Server metrics"""
        if self.data is None or self.data.empty:
            return {}

        self.logger.info("Analyzing SQL Server metrics...")

        # Calculate key metrics
        self.metrics = {
            'avg_dtu_percent': float(self.data['dtu_percent'].mean()),
            'max_dtu_percent': float(self.data['dtu_percent'].max()),
            'p95_dtu_percent': float(self.data['dtu_percent'].quantile(0.95)),
            'avg_cpu_percent': float(self.data['cpu_percent'].mean()),
            'max_cpu_percent': float(self.data['cpu_percent'].max()),
            'avg_query_time_ms': float(self.data['avg_query_time_ms'].mean()),
            'max_query_time_ms': float(self.data['avg_query_time_ms'].max()),
            'p95_query_time_ms': float(self.data['avg_query_time_ms'].quantile(0.95)),
            'avg_active_connections': float(self.data['active_connections'].mean()),
            'max_active_connections': int(self.data['active_connections'].max()),
            'total_blocked_connections': int(self.data['blocked_connections'].sum()),
            'total_deadlocks': int(self.data['deadlocks'].sum()),
            'total_slow_queries': int(self.data['slow_queries'].sum()),
            'total_failed_connections': int(self.data['failed_connections'].sum()),
            'unique_databases': int(self.data['database_name'].nunique()) if 'database_name' in self.data.columns else 0
        }

        # Detect anomalies
        self.anomalies = self.detect_anomalies()

        # Generate insights
        self.insights = self.get_insights()

        # Calculate health score
        health_score = self.calculate_health_score(
            {
                'dtu': self.metrics['p95_dtu_percent'],
                'cpu': self.metrics['max_cpu_percent'],
                'query_time': self.metrics['p95_query_time_ms'],
                'deadlocks': self.metrics['total_deadlocks']
            },
            {
                'dtu': self.thresholds['dtu_percent'],
                'cpu': self.thresholds['cpu_percent'],
                'query_time': self.thresholds['avg_query_time_ms'],
                'deadlocks': self.thresholds['deadlocks']
            }
        )

        # Database-level analysis
        db_analysis = {}
        if 'database_name' in self.data.columns:
            db_analysis = self.data.groupby('database_name').agg({
                'avg_query_time_ms': ['mean', 'max'],
                'slow_queries': 'sum',
                'deadlocks': 'sum',
                'active_connections': 'mean'
            }).round(2).to_dict()

        return {
            'service': 'SQLServer',
            'metrics': self.metrics,
            'anomalies': self.anomalies,
            'insights': self.insights,
            'health_score': health_score,
            'database_analysis': db_analysis,
            'time_series_data': self.data.to_dict('records')
        }

    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in SQL Server metrics"""
        anomalies = []

        # High DTU usage
        high_dtu = self.data[self.data['dtu_percent'] > self.thresholds['dtu_percent']]
        if len(high_dtu) > 0:
            anomalies.append({
                'type': 'High DTU Usage',
                'severity': 'high' if high_dtu['dtu_percent'].mean() > 90 else 'medium',
                'count': len(high_dtu),
                'description': f"{len(high_dtu)} instances of DTU usage above {self.thresholds['dtu_percent']}%",
                'max_value': float(high_dtu['dtu_percent'].max()),
                'timestamps': high_dtu['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S').tolist()[:5]
            })

        # Slow queries
        slow_queries = self.data[self.data['avg_query_time_ms'] > self.thresholds['avg_query_time_ms']]
        if len(slow_queries) > 0:
            anomalies.append({
                'type': 'Slow Query Performance',
                'severity': 'high' if slow_queries['avg_query_time_ms'].mean() > 1000 else 'medium',
                'count': len(slow_queries),
                'description': f"{len(slow_queries)} instances of slow query performance (>{self.thresholds['avg_query_time_ms']}ms)",
                'max_value': float(slow_queries['avg_query_time_ms'].max()),
                'avg_value': float(slow_queries['avg_query_time_ms'].mean())
            })

        # Blocking and deadlocks
        if self.metrics['total_blocked_connections'] > self.thresholds['blocked_connections']:
            blocked_incidents = self.data[self.data['blocked_connections'] > 0]
            anomalies.append({
                'type': 'Connection Blocking',
                'severity': 'high',
                'count': len(blocked_incidents),
                'description': f"Total of {self.metrics['total_blocked_connections']} blocked connections detected",
                'max_concurrent': int(self.data['blocked_connections'].max())
            })

        if self.metrics['total_deadlocks'] > 0:
            anomalies.append({
                'type': 'Deadlocks Detected',
                'severity': 'critical' if self.metrics['total_deadlocks'] > 10 else 'high',
                'count': self.metrics['total_deadlocks'],
                'description': f"{self.metrics['total_deadlocks']} deadlocks detected - indicates transaction conflicts"
            })

        # Failed connections
        if self.metrics['total_failed_connections'] > 10:
            anomalies.append({
                'type': 'Connection Failures',
                'severity': 'medium',
                'count': self.metrics['total_failed_connections'],
                'description': f"{self.metrics['total_failed_connections']} failed connection attempts"
            })

        return anomalies

    def get_insights(self) -> List[str]:
        """Generate actionable insights"""
        insights = []

        # DTU insights
        if self.metrics['p95_dtu_percent'] > self.thresholds['dtu_percent']:
            insights.append(
                f"⚠️ DTU utilization is high (P95: {self.metrics['p95_dtu_percent']:.1f}%). "
                f"Consider upgrading to a higher service tier."
            )

        # Query performance
        if self.metrics['p95_query_time_ms'] > self.thresholds['avg_query_time_ms']:
            insights.append(
                f"⚠️ Query performance is degraded (P95: {self.metrics['p95_query_time_ms']:.0f}ms). "
                f"Review query execution plans and add indexes."
            )

        # Deadlocks
        if self.metrics['total_deadlocks'] > 0:
            insights.append(
                f"🔴 {self.metrics['total_deadlocks']} deadlocks detected. "
                f"Review transaction isolation levels and query ordering."
            )

        # Blocking
        if self.metrics['total_blocked_connections'] > self.thresholds['blocked_connections']:
            insights.append(
                f"⚠️ Frequent connection blocking detected. "
                f"Optimize long-running queries and transaction durations."
            )

        # Connection patterns
        if self.metrics['avg_active_connections'] > 100:
            insights.append(
                f"📊 High connection count (avg: {self.metrics['avg_active_connections']:.0f}). "
                f"Consider connection pooling optimization."
            )

        # Positive insights
        if self.metrics['p95_dtu_percent'] < 60 and self.metrics['p95_query_time_ms'] < 200:
            insights.append("✅ SQL Server performance is healthy with good response times.")

        if self.metrics['total_deadlocks'] == 0:
            insights.append("✅ No deadlocks detected - excellent transaction management.")

        return insights
