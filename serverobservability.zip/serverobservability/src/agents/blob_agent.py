"""
Azure Blob Storage Agent
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from pathlib import Path

from .base_agent import BaseAgent

class BlobAgent(BaseAgent):
    """Agent for analyzing Azure Blob Storage metrics"""

    def __init__(self, data_dir: str):
        super().__init__("BlobStorage", data_dir)
        self.thresholds = {
            'avg_e2e_latency_ms': 100,
            'avg_server_latency_ms': 50,
            'throttled_requests': 10,
            'error_rate_percent': 5
        }

    def load_data(self) -> bool:
        """Load Blob Storage metrics from CSV files"""
        try:
            csv_files = list(self.data_dir.glob('*blob*.csv'))
            if not csv_files:
                self.logger.warning("No Blob Storage CSV files found")
                return False

            self.logger.info(f"Loading Blob Storage data from {csv_files[0]}")
            self.data = pd.read_csv(csv_files[0])
            self.data['timestamp'] = pd.to_datetime(self.data['timestamp'])

            # Calculate error rate
            if 'total_requests' in self.data.columns and 'successful_requests' in self.data.columns:
                failed = self.data['total_requests'] - self.data['successful_requests']
                self.data['error_rate_percent'] = (failed / self.data['total_requests'] * 100).fillna(0)

            return True

        except Exception as e:
            self.logger.error(f"Failed to load Blob Storage data: {e}")
            return False

    def analyze(self) -> Dict[str, Any]:
        """Analyze Blob Storage metrics"""
        if self.data is None or self.data.empty:
            return {}

        self.logger.info("Analyzing Blob Storage metrics...")

        # Calculate key metrics
        self.metrics = {
            'avg_e2e_latency_ms': float(self.data['avg_e2e_latency_ms'].mean()),
            'max_e2e_latency_ms': float(self.data['avg_e2e_latency_ms'].max()),
            'p95_e2e_latency_ms': float(self.data['avg_e2e_latency_ms'].quantile(0.95)),
            'avg_server_latency_ms': float(self.data['avg_server_latency_ms'].mean()),
            'max_server_latency_ms': float(self.data['avg_server_latency_ms'].max()),
            'total_requests': int(self.data['total_requests'].sum()),
            'total_successful_requests': int(self.data['successful_requests'].sum()),
            'total_throttled_requests': int(self.data['throttled_requests'].sum()),
            'avg_error_rate_percent': float(self.data['error_rate_percent'].mean()),
            'avg_ingress_mb': float(self.data['ingress_bytes'].mean() / 1024 / 1024),
            'avg_egress_mb': float(self.data['egress_bytes'].mean() / 1024 / 1024),
            'total_ingress_gb': float(self.data['ingress_bytes'].sum() / 1024 / 1024 / 1024),
            'total_egress_gb': float(self.data['egress_bytes'].sum() / 1024 / 1024 / 1024),
            'avg_transactions_per_sec': float(self.data['transactions_per_sec'].mean()),
            'unique_containers': int(self.data['container_name'].nunique()) if 'container_name' in self.data.columns else 0
        }

        # Calculate success rate
        self.metrics['success_rate_percent'] = (
            self.metrics['total_successful_requests'] / self.metrics['total_requests'] * 100
            if self.metrics['total_requests'] > 0 else 100
        )

        # Detect anomalies
        self.anomalies = self.detect_anomalies()

        # Generate insights
        self.insights = self.get_insights()

        # Calculate health score
        health_score = self.calculate_health_score(
            {
                'latency': self.metrics['p95_e2e_latency_ms'],
                'throttled': self.metrics['total_throttled_requests'],
                'error_rate': self.metrics['avg_error_rate_percent']
            },
            {
                'latency': self.thresholds['avg_e2e_latency_ms'],
                'throttled': self.thresholds['throttled_requests'],
                'error_rate': self.thresholds['error_rate_percent']
            }
        )

        # Container-level analysis
        container_analysis = {}
        if 'container_name' in self.data.columns:
            container_analysis = self.data.groupby('container_name').agg({
                'total_requests': 'sum',
                'successful_requests': 'sum',
                'throttled_requests': 'sum',
                'avg_e2e_latency_ms': 'mean',
                'ingress_bytes': 'sum',
                'egress_bytes': 'sum'
            }).round(2).to_dict()

        return {
            'service': 'BlobStorage',
            'metrics': self.metrics,
            'anomalies': self.anomalies,
            'insights': self.insights,
            'health_score': health_score,
            'container_analysis': container_analysis,
            'time_series_data': self.data.to_dict('records')
        }

    def detect_anomalies(self) -> List[Dict[str, Any]]:
        """Detect anomalies in Blob Storage metrics"""
        anomalies = []

        # High latency
        high_latency = self.data[self.data['avg_e2e_latency_ms'] > self.thresholds['avg_e2e_latency_ms']]
        if len(high_latency) > 0:
            anomalies.append({
                'type': 'High Latency',
                'severity': 'high' if high_latency['avg_e2e_latency_ms'].mean() > 500 else 'medium',
                'count': len(high_latency),
                'description': f"{len(high_latency)} instances of latency above {self.thresholds['avg_e2e_latency_ms']}ms",
                'max_value': float(high_latency['avg_e2e_latency_ms'].max()),
                'avg_value': float(high_latency['avg_e2e_latency_ms'].mean())
            })

        # Throttling
        throttled = self.data[self.data['throttled_requests'] > self.thresholds['throttled_requests']]
        if len(throttled) > 0:
            anomalies.append({
                'type': 'Request Throttling',
                'severity': 'high',
                'count': len(throttled),
                'description': f"{self.metrics['total_throttled_requests']} requests were throttled",
                'max_concurrent': int(self.data['throttled_requests'].max()),
                'affected_containers': throttled['container_name'].unique().tolist()[:5] if 'container_name' in throttled.columns else []
            })

        # High error rate
        high_errors = self.data[self.data['error_rate_percent'] > self.thresholds['error_rate_percent']]
        if len(high_errors) > 0:
            anomalies.append({
                'type': 'High Error Rate',
                'severity': 'critical' if high_errors['error_rate_percent'].mean() > 10 else 'high',
                'count': len(high_errors),
                'description': f"{len(high_errors)} periods with error rate above {self.thresholds['error_rate_percent']}%",
                'max_value': float(high_errors['error_rate_percent'].max()),
                'avg_value': float(high_errors['error_rate_percent'].mean())
            })

        # Network latency vs server latency
        network_latency = self.data['avg_e2e_latency_ms'] - self.data['avg_server_latency_ms']
        high_network_latency = network_latency > 100
        if high_network_latency.sum() > len(self.data) * 0.1:  # More than 10% of samples
            anomalies.append({
                'type': 'Network Latency Issues',
                'severity': 'medium',
                'count': int(high_network_latency.sum()),
                'description': f"High network latency detected (avg: {network_latency.mean():.1f}ms)",
                'note': 'Network latency significantly higher than server processing time'
            })

        return anomalies

    def get_insights(self) -> List[str]:
        """Generate actionable insights"""
        insights = []

        # Latency insights
        if self.metrics['p95_e2e_latency_ms'] > self.thresholds['avg_e2e_latency_ms']:
            insights.append(
                f"⚠️ End-to-end latency is high (P95: {self.metrics['p95_e2e_latency_ms']:.0f}ms). "
                f"Consider using Azure CDN or optimizing blob access patterns."
            )

        # Throttling insights
        throttle_rate = (self.metrics['total_throttled_requests'] / self.metrics['total_requests'] * 100)
        if throttle_rate > 1:
            insights.append(
                f"⚠️ {throttle_rate:.2f}% of requests were throttled. "
                f"Review storage account limits and consider request batching."
            )

        # Error rate insights
        if self.metrics['avg_error_rate_percent'] > self.thresholds['error_rate_percent']:
            insights.append(
                f"🔴 Error rate is {self.metrics['avg_error_rate_percent']:.2f}%. "
                f"Investigate client errors and implement retry logic."
            )

        # Bandwidth insights
        egress_ingress_ratio = self.metrics['total_egress_gb'] / self.metrics['total_ingress_gb'] if self.metrics['total_ingress_gb'] > 0 else 0
        if egress_ingress_ratio > 5:
            insights.append(
                f"📊 Egress is {egress_ingress_ratio:.1f}x higher than ingress ({self.metrics['total_egress_gb']:.2f}GB out). "
                f"Consider caching frequently accessed blobs."
            )

        # Performance insights
        network_overhead = self.metrics['avg_e2e_latency_ms'] - self.metrics['avg_server_latency_ms']
        if network_overhead > 50:
            insights.append(
                f"⚠️ Network overhead is {network_overhead:.0f}ms. "
                f"Consider geographic distribution or compression."
            )

        # Positive insights
        if self.metrics['success_rate_percent'] > 99.5:
            insights.append(f"✅ Excellent reliability with {self.metrics['success_rate_percent']:.2f}% success rate.")

        if self.metrics['p95_e2e_latency_ms'] < 50:
            insights.append("✅ Blob storage latency is excellent.")

        return insights
