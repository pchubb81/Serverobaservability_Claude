"""
Chart generator using Plotly for interactive visualizations
"""

import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
from typing import Dict, Any, List

class ChartGenerator:
    """Generate interactive charts using Plotly"""

    def __init__(self):
        self.default_colors = px.colors.qualitative.Set3

    def create_health_score_gauge(self, score: float, title: str = "Health Score") -> go.Figure:
        """Create a gauge chart for health score"""
        fig = go.Figure(go.Indicator(
            mode="gauge+number+delta",
            value=score,
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': title, 'font': {'size': 24}},
            delta={'reference': 80, 'increasing': {'color': "green"}},
            gauge={
                'axis': {'range': [None, 100], 'tickwidth': 1, 'tickcolor': "darkblue"},
                'bar': {'color': self._get_health_color(score)},
                'bgcolor': "white",
                'borderwidth': 2,
                'bordercolor': "gray",
                'steps': [
                    {'range': [0, 40], 'color': '#ffcccc'},
                    {'range': [40, 60], 'color': '#ffffcc'},
                    {'range': [60, 80], 'color': '#e6f3ff'},
                    {'range': [80, 100], 'color': '#ccffcc'}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 70
                }
            }
        ))

        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=60, b=20),
            font={'size': 16}
        )

        return fig

    def create_time_series_chart(self, df: pd.DataFrame, x_col: str, y_cols: List[str],
                                 title: str, y_label: str = "") -> go.Figure:
        """Create a time series line chart"""
        fig = go.Figure()

        for i, col in enumerate(y_cols):
            if col in df.columns:
                fig.add_trace(go.Scatter(
                    x=df[x_col],
                    y=df[col],
                    mode='lines',
                    name=col.replace('_', ' ').title(),
                    line=dict(width=2)
                ))

        fig.update_layout(
            title=title,
            xaxis_title=x_col.replace('_', ' ').title(),
            yaxis_title=y_label,
            hovermode='x unified',
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            height=400,
            template='plotly_white'
        )

        return fig

    def create_bar_chart(self, data: Dict[str, float], title: str,
                         x_label: str = "", y_label: str = "") -> go.Figure:
        """Create a horizontal bar chart"""
        keys = list(data.keys())
        values = list(data.values())

        fig = go.Figure(go.Bar(
            x=values,
            y=keys,
            orientation='h',
            marker=dict(
                color=values,
                colorscale='RdYlGn_r',
                showscale=True
            ),
            text=[f'{v:.1f}' for v in values],
            textposition='auto'
        ))

        fig.update_layout(
            title=title,
            xaxis_title=x_label,
            yaxis_title=y_label,
            height=max(300, len(keys) * 40),
            template='plotly_white'
        )

        return fig

    def create_service_status_pie(self, system_health: Dict[str, Any]) -> go.Figure:
        """Create pie chart showing service status distribution"""
        labels = ['Healthy', 'Warning', 'Degraded', 'Critical']
        values = [
            system_health.get('services_healthy', 0),
            system_health.get('services_warning', 0),
            system_health.get('services_degraded', 0),
            system_health.get('services_critical', 0)
        ]

        colors = ['#4CAF50', '#FFC107', '#FF9800', '#F44336']

        fig = go.Figure(data=[go.Pie(
            labels=labels,
            values=values,
            hole=0.4,
            marker=dict(colors=colors),
            textposition='auto',
            textinfo='label+value'
        )])

        fig.update_layout(
            title="Service Status Distribution",
            height=350,
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5)
        )

        return fig

    def create_anomaly_heatmap(self, agent_results: Dict[str, Any]) -> go.Figure:
        """Create heatmap showing anomaly counts by service and type"""
        services = []
        anomaly_types = set()
        data = {}

        # Collect all anomalies
        for service, result in agent_results.items():
            if service == 'correlation_analysis':
                continue
            if isinstance(result, dict) and 'anomalies' in result:
                services.append(service)
                for anomaly in result['anomalies']:
                    atype = anomaly.get('type', 'Unknown')
                    anomaly_types.add(atype)

                    key = (service, atype)
                    data[key] = data.get(key, 0) + 1

        anomaly_types = sorted(list(anomaly_types))

        # Build matrix
        z_data = []
        for atype in anomaly_types:
            row = []
            for service in services:
                row.append(data.get((service, atype), 0))
            z_data.append(row)

        fig = go.Figure(data=go.Heatmap(
            z=z_data,
            x=services,
            y=anomaly_types,
            colorscale='Reds',
            text=z_data,
            texttemplate='%{text}',
            textfont={"size": 12},
            showscale=True
        ))

        fig.update_layout(
            title="Anomaly Distribution by Service",
            xaxis_title="Service",
            yaxis_title="Anomaly Type",
            height=max(300, len(anomaly_types) * 40),
            template='plotly_white'
        )

        return fig

    def create_correlation_network(self, correlations: List[Dict]) -> go.Figure:
        """Create network graph showing service correlations"""
        # This is a simplified version - could be enhanced with networkx
        if not correlations:
            return go.Figure()

        # Extract unique services
        services = set()
        for corr in correlations:
            services.update(corr['services'])

        services = list(services)

        # Create adjacency matrix
        n = len(services)
        z_data = [[0] * n for _ in range(n)]

        for corr in correlations:
            if len(corr['services']) >= 2:
                s1, s2 = corr['services'][:2]
                i1, i2 = services.index(s1), services.index(s2)
                z_data[i1][i2] = abs(corr['correlation'])
                z_data[i2][i1] = abs(corr['correlation'])

        fig = go.Figure(data=go.Heatmap(
            z=z_data,
            x=services,
            y=services,
            colorscale='Blues',
            text=[[f'{val:.2f}' if val > 0 else '' for val in row] for row in z_data],
            texttemplate='%{text}',
            textfont={"size": 12},
            showscale=True
        ))

        fig.update_layout(
            title="Service Correlation Matrix",
            xaxis_title="Service",
            yaxis_title="Service",
            height=400,
            template='plotly_white'
        )

        return fig

    def _get_health_color(self, score: float) -> str:
        """Get color based on health score"""
        if score >= 80:
            return "green"
        elif score >= 60:
            return "lightgreen"
        elif score >= 40:
            return "orange"
        else:
            return "red"

    def create_metric_comparison(self, services_data: Dict[str, Dict], metric_name: str,
                                 title: str) -> go.Figure:
        """Create comparison chart for a specific metric across services"""
        services = []
        values = []

        for service, data in services_data.items():
            if metric_name in data:
                services.append(service)
                values.append(data[metric_name])

        fig = go.Figure(data=[
            go.Bar(
                x=services,
                y=values,
                marker_color=self.default_colors[:len(services)],
                text=[f'{v:.1f}' for v in values],
                textposition='auto'
            )
        ])

        fig.update_layout(
            title=title,
            xaxis_title="Service",
            yaxis_title=metric_name.replace('_', ' ').title(),
            height=350,
            template='plotly_white'
        )

        return fig
