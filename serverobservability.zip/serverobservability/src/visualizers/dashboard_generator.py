"""
Interactive HTML Dashboard Generator
"""

import pandas as pd
from pathlib import Path
from typing import Dict, Any
from datetime import datetime
import plotly.io as pio

from .chart_generator import ChartGenerator

class DashboardGenerator:
    """Generate interactive HTML dashboard with all visualizations"""

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.chart_gen = ChartGenerator()

    def generate(self, results: Dict[str, Any]) -> str:
        """Generate dashboard HTML file

        Args:
            results: Analysis results from all agents

        Returns:
            Path to generated dashboard
        """
        summary = results.get('summary', {})
        correlation_analysis = results.get('correlation_analysis', {})
        system_health = correlation_analysis.get('system_health', {})

        # Generate all charts
        charts_html = []

        # 1. System Health Gauge
        if system_health.get('overall_score'):
            health_gauge = self.chart_gen.create_health_score_gauge(
                system_health['overall_score'],
                "Overall System Health"
            )
            charts_html.append(pio.to_html(health_gauge, include_plotlyjs='cdn', full_html=False))

        # 2. Service Status Pie
        if system_health:
            status_pie = self.chart_gen.create_service_status_pie(system_health)
            charts_html.append(pio.to_html(status_pie, include_plotlyjs=False, full_html=False))

        # 3. Anomaly Heatmap
        anomaly_heatmap = self.chart_gen.create_anomaly_heatmap(results)
        charts_html.append(pio.to_html(anomaly_heatmap, include_plotlyjs=False, full_html=False))

        # 4. Correlation Network
        if correlation_analysis.get('correlations'):
            corr_network = self.chart_gen.create_correlation_network(correlation_analysis['correlations'])
            charts_html.append(pio.to_html(corr_network, include_plotlyjs=False, full_html=False))

        # 5. Service-specific charts
        for service in ['AKS', 'SQLServer', 'BlobStorage', 'API', 'RedisCache']:
            if service in results and results[service].get('time_series_data'):
                service_charts = self._generate_service_charts(service, results[service])
                charts_html.extend(service_charts)

        # Build HTML
        html_content = self._build_html(summary, system_health, correlation_analysis, charts_html)

        # Save dashboard
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        dashboard_path = self.output_dir / f'dashboard_{timestamp}.html'
        dashboard_path.write_text(html_content, encoding='utf-8')

        return str(dashboard_path)

    def _generate_service_charts(self, service: str, service_data: Dict[str, Any]) -> list:
        """Generate charts for a specific service"""
        charts = []

        df = pd.DataFrame(service_data['time_series_data'])
        if df.empty or 'timestamp' not in df.columns:
            return charts

        df['timestamp'] = pd.to_datetime(df['timestamp'])

        # Service-specific charts
        if service == 'AKS':
            # CPU and Memory over time
            fig = self.chart_gen.create_time_series_chart(
                df.groupby('timestamp').mean(numeric_only=True).reset_index(),
                'timestamp',
                ['cpu_usage_percent', 'memory_usage_percent'],
                f'{service}: Resource Usage Over Time',
                'Percentage (%)'
            )
            charts.append(pio.to_html(fig, include_plotlyjs=False, full_html=False))

        elif service == 'SQLServer':
            # Query performance over time
            fig = self.chart_gen.create_time_series_chart(
                df,
                'timestamp',
                ['avg_query_time_ms', 'dtu_percent'],
                f'{service}: Performance Metrics',
                'Value'
            )
            charts.append(pio.to_html(fig, include_plotlyjs=False, full_html=False))

        elif service == 'BlobStorage':
            # Latency over time
            fig = self.chart_gen.create_time_series_chart(
                df,
                'timestamp',
                ['avg_e2e_latency_ms', 'avg_server_latency_ms'],
                f'{service}: Latency Metrics',
                'Milliseconds'
            )
            charts.append(pio.to_html(fig, include_plotlyjs=False, full_html=False))

        elif service == 'API':
            # Response time and error rate
            fig = self.chart_gen.create_time_series_chart(
                df,
                'timestamp',
                ['response_time_ms'],
                f'{service}: Response Time',
                'Milliseconds'
            )
            charts.append(pio.to_html(fig, include_plotlyjs=False, full_html=False))

        elif service == 'RedisCache':
            # Cache hit rate and memory
            fig = self.chart_gen.create_time_series_chart(
                df,
                'timestamp',
                ['cache_hit_rate', 'memory_percent'],
                f'{service}: Cache Performance',
                'Value'
            )
            charts.append(pio.to_html(fig, include_plotlyjs=False, full_html=False))

        return charts

    def _build_html(self, summary: Dict, system_health: Dict,
                   correlation_analysis: Dict, charts_html: list) -> str:
        """Build complete HTML dashboard"""
        bottlenecks = correlation_analysis.get('bottlenecks', [])
        correlations = correlation_analysis.get('correlations', [])

        bottlenecks_html = ""
        if bottlenecks:
            bottlenecks_html = "<h3>🔴 Critical Bottlenecks</h3><ul>"
            for bn in bottlenecks[:5]:
                bottlenecks_html += f"""
                <li>
                    <strong>{bn.get('service')}</strong> - {bn.get('type')}<br>
                    <small>{bn.get('description')}</small>
                </li>
                """
            bottlenecks_html += "</ul>"

        correlations_html = ""
        if correlations:
            correlations_html = "<h3>🔗 Service Correlations</h3><ul>"
            for corr in correlations[:5]:
                correlations_html += f"""
                <li>
                    <strong>{' ↔️ '.join(corr.get('services', []))}</strong><br>
                    <small>{corr.get('description')} (r={corr.get('correlation', 0):.2f})</small>
                </li>
                """
            correlations_html += "</ul>"

        charts_section = "\n".join([f'<div class="chart-container">{chart}</div>' for chart in charts_html])

        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Azure Performance Observability Dashboard</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            color: #333;
        }}

        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }}

        header {{
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}

        header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}

        header p {{
            font-size: 1.1em;
            opacity: 0.9;
        }}

        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
        }}

        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }}

        .stat-card .value {{
            font-size: 2.5em;
            font-weight: bold;
            margin: 10px 0;
        }}

        .stat-card .label {{
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}

        .stat-card.healthy .value {{ color: #4CAF50; }}
        .stat-card.warning .value {{ color: #FFC107; }}
        .stat-card.critical .value {{ color: #F44336; }}

        .content {{
            padding: 30px;
        }}

        .section {{
            margin-bottom: 40px;
        }}

        h2 {{
            color: #1e3c72;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
        }}

        h3 {{
            color: #2a5298;
            margin-bottom: 15px;
        }}

        .chart-container {{
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}

        ul {{
            list-style: none;
            padding: 0;
        }}

        ul li {{
            background: #f8f9fa;
            margin: 10px 0;
            padding: 15px;
            border-left: 4px solid #667eea;
            border-radius: 5px;
        }}

        ul li strong {{
            color: #1e3c72;
        }}

        ul li small {{
            display: block;
            margin-top: 5px;
            color: #666;
        }}

        footer {{
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }}

        .status-badge {{
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9em;
        }}

        .status-healthy {{ background: #4CAF50; color: white; }}
        .status-warning {{ background: #FFC107; color: #333; }}
        .status-degraded {{ background: #FF9800; color: white; }}
        .status-critical {{ background: #F44336; color: white; }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🔍 Azure Performance Observability Dashboard</h1>
            <p>Comprehensive Multi-Service Analysis & Insights</p>
            <p style="font-size: 0.9em; margin-top: 10px;">Generated: {summary.get('analysis_timestamp', 'N/A')}</p>
        </header>

        <div class="summary">
            <div class="stat-card {self._get_status_class(system_health.get('overall_status', 'unknown'))}">
                <div class="label">System Health</div>
                <div class="value">{system_health.get('overall_score', 'N/A')}</div>
                <div class="status-badge status-{system_health.get('overall_status', 'unknown')}">
                    {system_health.get('overall_status', 'Unknown').upper()}
                </div>
            </div>

            <div class="stat-card">
                <div class="label">Services Analyzed</div>
                <div class="value">{summary.get('services_analyzed', 0)}</div>
            </div>

            <div class="stat-card {self._get_anomaly_class(summary.get('total_anomalies', 0))}">
                <div class="label">Anomalies Detected</div>
                <div class="value">{summary.get('total_anomalies', 0)}</div>
            </div>

            <div class="stat-card critical">
                <div class="label">Bottlenecks</div>
                <div class="value">{summary.get('bottlenecks_count', 0)}</div>
            </div>
        </div>

        <div class="content">
            <div class="section">
                {bottlenecks_html}
                {correlations_html}
            </div>

            <div class="section">
                <h2>📊 Performance Visualizations</h2>
                {charts_section}
            </div>
        </div>

        <footer>
            <p>Azure Server Performance Observability System</p>
            <p>AI-Powered Multi-Service Analysis & Bottleneck Detection</p>
        </footer>
    </div>
</body>
</html>
"""
        return html

    def _get_status_class(self, status: str) -> str:
        """Get CSS class for status"""
        status_map = {
            'healthy': 'healthy',
            'warning': 'warning',
            'degraded': 'warning',
            'critical': 'critical'
        }
        return status_map.get(status.lower(), '')

    def _get_anomaly_class(self, count: int) -> str:
        """Get CSS class for anomaly count"""
        if count == 0:
            return 'healthy'
        elif count < 10:
            return 'warning'
        else:
            return 'critical'
